DriveRight FMS 3.4 Release Notes April 29 2005

Important Note:

Using CarChip Fleet and Fleet with alarm in FMS:
 
As part of this software, we have also included our consumer CarChip software in a separate folder called "CarChip Installer".  CarChip has 
several additional features  in addition to the safety data DriveRight handles, and these features are accessed only in the CarChip software.  
Install CarChip software if you have CarChips, and plan to use the following:
 
Diagnostic Code reading and resetting
Graphs of individual trip speed data
Tables and graphs for data on the additional parameters CarChip logs (RPM, coolant temperature, etc.)


I. Introduction

Thank you very much for installing DriveRight FMS 3.4. All the documentation is provided in the folder 'docs' 
on the CD. Once you install the software all these documents are copied to the install directory. Before you 
run the software please go through 'Getting Started Guide.pdf'. To view files with .pdf extension, 
you need Adobe Acrobat Reader. If you already have Acrobat Reader installed, your system will recognize and 
open the document. Otherwise, you can install the Acrobat Reader included with the CD, in the folder 'pdfRead'. 
Double-Click on ar505enu.exe to run the setup for Acrobat Reader.    

Please feel free to report your findings in any manner that suits you.  We ask only that you send all the 
feedback to support@davisnet.com . For your convenience, we included a list of questions in section IV. 
Feedback. Your feedback will go a long way in helping Davis Instruments create a  high quality product that 
satisfies your needs. 

II. System Requirements:
�	Operating System: Windows 98SE/Win NT4.0/Win ME/Win 2000/Win XP
�	RAM: 32MB (64MB or more recommended)
�	Resolution: 800x600 or higher recommended

III. Installation

The installation of 3.4 should not effect your older 2.0x/2.6.1 program.  The default install directory is 
set to diskDrive:/Program Files/DriveRight/. The install program will create a new �DriveRight FMS� 
shortcut on your desktop, and you will also be able to launch the new program from the Start menu by 
selecting Start->Programs->DriveRight->DriveRight FMS. Follow the instructions mentioned in 
�Getting Started Guide.pdf� to install and configure the DriveRight FMS software.

IV.Feature Set

FMS 3.1

The DriveRight Fleet Management Software (FMS) allows you to store, view, and manipulate DriveRight data on your Windows-compatible computer. 
More specifically, FMS provides tools for sorting, tracking, analyzing and printing data, and viewing and printing reports for a number of 
individual DriveRight consoles at a number of different locations. 

 
DriveRight FMS 3.1 features include:

Tracking drivers, vehicles, locations, and service
Viewing, graphing, printing and saving "accident log" information
Multiple user levels 
Tamper logs
Sorting data and creating reports according to user-defined selection criteria
Summarize data by day and by trip
Integrated Microsoft MapPoint support for mapping of GPS data
Compare vehicles, drivers, or groups of drivers
FTP Export / FTP Import data
Palm download support

FMS 3.2

DriveRight Fleet Management Software version 3.2 includes the following changes:

�Driver Safety Score Report: (Previously it's called as Driver Performance Score report)   
Changes have been made to this report in order to support exempt driver functionality.                        
Support for multiple locations.
Formula Dialog change.
User can choose to display both heavy and light vehicles or *only* light vehicles. User can choose to allow scores below zero. (If not selected then scores below zero default to zero value)
Report is going to include new column showing the DriveRight device speed limit and calculation of the score is based on that speed limit.

�Safety Score Report Summary:
Support for multiple locations.
Rolling summary report over a period of 3,6,12 months.  
Support for recalculating the score if user edited certain trips through the trips browser.

�Safety Score database table:
Added new Safety Score database table for browsing and editing the records.
Provide filter for browsing selected drivers in a particular period of time.
Support Backup, Restore, LAN Export, LAN Import, FTP Export and FTP Import for Safety Score table.

�MapPoint Integration:
Integrated MapPoint ActiveX control in the application.
Support for showing Accident Logs on the map and at the same time export to excel sheet for graphical display of the logs. Users will be able to see the trip made during a particular accident log by double clicking on the log.
Support for showing individual trips and trips made by a particular driver in a day.
Implemented Email and printing capabilities of the generated map by automating Microsoft Outlook through FMS application.
Provided data mapping wizard for specifying speed limits(Allowed up to 8 different ranges).
Users will be able to save the generated map and open it when necessary to view the saved map.

�Tamper Logs Report:
Displaying the time between unplugging the DriveRight device from the vehicle and downloading the device, time taken by the driver  to reconnect the device once finished the downloading


�Exclusive Driver:
Make changes to the Vehicles user interface while adding, editing and browsing Vehicles database table that supports exclusive driver for a particular vehicle. 
Implemented necessary changes while downloading the device based on exclusive driver logic.


�New Menu Items:
Added new menu items for Safety Score Summary report and Safety Score database table.

�Excel templates:
Fixed the problems with Accident report template for emailing.
Changed all the excel templates to excel worksheets.
Fixed up bugs while opening saved template sheets and emailing the saved workbooks.



FMS 3.3

DriveRight Fleet Management Software version 3.3 includes the following changes:

The Inclusion of using an on-board and desktop reader and SmartCard system to transfer data from the DriveRight 600 and 500AL unit to a computer. 
This added feature has created the following changes to the FMS software.

New menu option in the Setup Menu: SmartCard Reader. Lets you select the SmartCard reader type. The SmartCard Reader requires USB driver 
installation before the SmartCard Reader can be determined and set up.

New menu: SmartCard Menu. The SmartCard menu contains several menu options for setting up, monitoring, and maintaining all the SmartCards and 
DriveRights using the SmartCard System. The SmartCard menu options are:

Download  - Downloads information stored on a card to a selected base from a SmartCard Reader.
Setup Card - Allows you to select user and vehicle information for a card.
Transfer to DriveRight - Uses the card to transfer settings and information to a DriveRight or multiple DriveRight devices.
Clear Transfer Data - Clears the settings and data that sets the DriveRight
Erase - Erases all data stored on the SmartCard



FMS 3.4 

DriveRight Fleet Management Software version 3.4 includes the following changes:

New option in Setup Menu: Corporate Structure. The Corporate Structure option allows you to create a hierarchical representation of 
fleets and how they are distributed company wide. This feature is used in conjunction with the Driver Safety Score Report in the Reports Menu.

A new option in the Drive Safety Score Report: Specify Drivers with Mileage option, which displays all drivers with mileage for the specified time period.

The Serial Port options for both DriveRight and CarChip changed to Communication Port in the Setup Menu, with added USB support.

USB support for Fleet CarChips added.




V. Feedback

Contact Person:
	Phone:
	Email: 

System Information:
Operating System?
CPU?
Display Resolution and Colors?  (See Settings/Control Panel/Display/Settings)

Database tested? (MsAccess, MySQL, MSDE, SQL Server, Oracle)

Approximately how may vehicles do you track data for?
 
Do you have experience with the older 2.0x DriveRight software?

Did you have any problems installing the new software?

Did you have any trouble converting your old data tables?

Anything you liked about 2.0x that you wish was in 3.4?

What additional functionality would you like to see added to 3.4?

Any additional comments you would like to make?





Thanks again from the Davis DriveRight team!
