CREATE TABLE CompanyLocations (locationID        NUMBER(5) PRIMARY KEY, 
                               locationName      CHAR(40)  NOT NULL   ,
      			       locationAddress   CHAR(80)  ,
                               parentLocationID  NUMBER(5));

CREATE TABLE DriveRights (locationID        NUMBER(5)  NOT NULL, 
			  driveRightID      NUMBER(5)  NOT NULL, 
 			  vehicleID         NUMBER(5)          ,
		          driveRightType    NUMBER(5)          ,
			  speedLimit        NUMBER(5)          ,
		          accelLimit        NUMBER(5)          ,
      			  decelLimit        NUMBER(5)          ,
		          settingsCode      NUMBER(5)          ,
                          stopTime          NUMBER(5)          ,
                          logOutTime        NUMBER(5)          ,
                          VSS               NUMBER(6)          ,
                          pulsesPerReading  NUMBER(5)          ,
                          calibrationNumber NUMBER(6)          ,
                          distanceUnit      CHAR(1)	       ,
      			  dateMode          CHAR(1)	       ,
		          timeMode          CHAR(1)	       ,
			  alarmMode         CHAR(1)	       ,
			  warnNotLogged     CHAR(1)	       ,
                          tamperLight       CHAR(1)            ,
     		          activeField	    CHAR(1)  	       ,
                          remarks           CHAR(80)	       ,	
            		  PRIMARY KEY (locationID, driveRightID) );

CREATE TABLE CarChips  (locationID        NUMBER(5)  NOT NULL,
			carChipID         NUMBER(5)  NOT NULL,   
	  		serialNumber      CHAR(20)   NOT NULL,
	  		carChipType       NUMBER(5)  	     ,
      			vehicleID         NUMBER(5)  	     ,
     			driverID          NUMBER(5)  	     ,
      			speedBand1        NUMBER(5)  	     ,
	  		speedBand2        NUMBER(5)  	     ,
	  		speedBand3        NUMBER(5)  	     ,
      			hardBraking       FLOAT              ,
	  		extremeBraking    FLOAT              ,
	  		hardAccel         FLOAT              ,
	  		extremeAccel      FLOAT              ,
      			parameter1        NUMBER(5)	     ,
      			interval1         NUMBER(5)	     ,
	  		parameter2        NUMBER(5)	     ,
      			interval2         NUMBER(5)	     ,
	  		parameter3        NUMBER(5)	     ,
      			interval3         NUMBER(5)           ,
	  		parameter4        NUMBER(5)          ,
      			interval4         NUMBER(5)	     ,
			PRIMARY KEY (locationID, carChipID) );


CREATE TABLE DriverGroups (locationID       NUMBER(5)  NOT NULL, 
		      	   groupNumber      NUMBER(5)  NOT NULL, 
			   groupName        CHAR(60)   NOT NULL, 
      			   remarks          CHAR(60)           , 
			   PRIMARY KEY (locationID, groupNumber));

CREATE TABLE Drivers (locationID        NUMBER(5)  NOT NULL, 
   		      driverID          NUMBER(5)  NOT NULL, 
                      groupNumber       NUMBER(5)  	   , 
                      driverName        CHAR(60)   NOT NULL,
                      initials          CHAR(5)            ,
                      address           CHAR(80)	   ,
                      city_state        CHAR(60)       	   ,
                      zipCode           CHAR(20)     	   ,
                      phoneNumber       CHAR(20)   	   ,
                      email             CHAR(80)           ,
                      companyName       CHAR(80)   	   ,
                      employeeID        CHAR(15)           ,
      		      activeField	CHAR(1)  	   ,
                      remarks           CHAR(80)	   ,
	              PRIMARY KEY (locationID, driverID));

CREATE TABLE Fleets (locationID        NUMBER(5)  NOT NULL, 
                     fleetNumber       NUMBER(5)  NOT NULL, 
                     fleetName         CHAR(40)   NOT NULL,
         	     PRIMARY KEY (locationID, fleetNumber));

CREATE TABLE Vehicles (locationID        NUMBER(5)  NOT NULL, 
                       vehicleID         NUMBER(5)  NOT NULL, 
                       vehicleNumber     CHAR(80)	    ,
	               fleetNumber       NUMBER(5)  NOT NULL, 
                       driveRightID      NUMBER(5)  NOT NULL, 
                       driverID          NUMBER(5)  NOT NULL, 
                       make_model        CHAR(80)      	    ,
                       licensePlate      CHAR(20)  	    ,
                       color             CHAR(10)           ,
                       purchaseDate      DATE               ,                       
                       currentOdometer   FLOAT      NOT NULL,
	               vehicleType       NUMBER(5)          ,
                       digitalInputs     CHAR(1)            , 
   		       activeField	 CHAR(1)  	    ,
                       remarks           CHAR(80)	    ,
       	               PRIMARY KEY (locationID, vehicleID));

CREATE TABLE Trips (locationID        NUMBER(5)  NOT NULL, 
	            driveRightID      NUMBER(5)  NOT NULL, 
	            driverID          NUMBER(5)  NOT NULL, 
                    startDateTime     DATE       NOT NULL,
                    endDateTime       DATE       NOT NULL,
                    tripTime          NUMBER(5)  NOT NULL, 
                    distance          FLOAT      NOT NULL, 
                    vehicleID         NUMBER(5)  NOT NULL, 
                    averageSpeed      NUMBER(5)  NOT NULL, 
                    topSpeed          NUMBER(5)  NOT NULL, 
                    timeOverSpeed     NUMBER(6)  NOT NULL, 
	            startOdometer     FLOAT      NOT NULL,
	            endOdometer       FlOAT      NOT NULL,
                    accelCount        NUMBER(5)  NOT NULL, 
                    decelCount        NUMBER(5)  NOT NULL, 
                    tripType          CHAR(1)    NOT NULL,
	            fromAddress       NUMBER(5)          , 
                    toAddress         NUMBER(5)          , 
                    reason            CHAR(80)  	 ,
                    startState        CHAR(1)            ,
                    endState          CHAR(1)	  	 ,
	            PRIMARY KEY (locationID, driveRightID, driverID, startDateTime));

CREATE TABLE TripAddresses (locationID        NUMBER(5)  NOT NULL, 
	                    addressID         NUMBER(5)  NOT NULL, 
                            name              CHAR(80)   NOT NULL,
                            companyName       CHAR(40)	         ,
                            contactPerson     CHAR(40)		 ,
                            address           CHAR(80)		 ,
                            city              CHAR(40)		 ,
                            state             CHAR(40)		 ,
                            zipCode           CHAR(40)		 ,
                            country           CHAR(40)		 ,
                            telephone         CHAR(20)		 ,
                            fax               CHAR(20)		 ,
                            email             CHAR(80)		 ,
                            latitude          FLOAT		 ,
                            longitude         FLOAT		 ,
                            elevation         FLOAT		 ,
                            addressRadius     NUMBER(5)  	 , 
                            ExtraStr          CHAR(80)		 ,
                            ExtraInt1         NUMBER(5)		 ,
                            ExtraInt2         NUMBER(5)		 ,
	                    PRIMARY KEY (locationID, addressID));

CREATE TABLE TamperLogs (locationID        NUMBER(5)  NOT NULL, 
                         driveRightID      NUMBER(5)  NOT NULL, 
	                 tamperDateTime    DATE       NOT NULL,
	                 downloadDateTime  DATE	              ,
                         driverID          NUMBER(5)  NOT NULL, 
	                 cause             NUMBER(5)  NOT NULL, 
	                 PRIMARY KEY (locationID, driveRightID, tamperDateTime, cause));

CREATE TABLE AccidentLogs (locationID         NUMBER(5)  NOT NULL, 
         		   driveRightID       NUMBER(5)  NOT NULL,
		 	   accidentDateTime   DATE       NOT NULL,
                           driverID           NUMBER(5)  NOT NULL,
                           realOrDecel        CHAR(1)	 NOT NULL,
                           cause	      CHAR(1)	         ,
                           before_T19         NUMBER(5)          ,
                           brakeBefore_T19    CHAR(1) 		 ,
                           before_T18         NUMBER(5)          ,
                           brakeBefore_T18    CHAR(1) 		 ,
                           before_T17         NUMBER(5)          ,
                           brakeBefore_T17    CHAR(1) 		 ,
                           before_T16         NUMBER(5)          ,
                           brakeBefore_T16    CHAR(1) 		 ,
                           before_T15         NUMBER(5)          ,
                           brakeBefore_T15    CHAR(1) 		 ,
                           before_T14         NUMBER(5)          ,
                           brakeBefore_T14    CHAR(1) 		 ,
                           before_T13         NUMBER(5)          ,
                           brakeBefore_T13    CHAR(1) 		 ,
                           before_T12         NUMBER(5)          ,
                           brakeBefore_T12    CHAR(1) 		 ,
                           before_T11         NUMBER(5)          ,
                           brakeBefore_T11    CHAR(1) 		 ,
                           before_T10         NUMBER(5)          ,
                           brakeBefore_T10    CHAR(1) 		 ,
                           before_T09         NUMBER(5)          ,
                           brakeBefore_T09    CHAR(1) 		 ,
                           before_T08         NUMBER(5)          ,
                           brakeBefore_T08    CHAR(1) 		 ,
                           before_T07         NUMBER(5)          ,
                           brakeBefore_T07    CHAR(1) 		 ,
                           before_T06         NUMBER(5)          ,
                           brakeBefore_T06    CHAR(1) 		 ,
                           before_T05         NUMBER(5)          ,
                           brakeBefore_T05    CHAR(1) 		 ,
                           before_T04         NUMBER(5)          ,
                           brakeBefore_T04    CHAR(1) 		 ,
                           before_T03         NUMBER(5)          ,
                           brakeBefore_T03    CHAR(1) 		 ,
                           before_T02         NUMBER(5)          ,
                           brakeBefore_T02    CHAR(1) 		 ,
                           before_T01         NUMBER(5)          ,
                           brakeBefore_T01    CHAR(1) 		 ,
	                   time_T0            NUMBER(5)          ,
                           brakeAt_T0	      CHAR(1) 		 ,
	                   after_T01          NUMBER(5)          ,
                           brakeAfter_T01     CHAR(1) 		 ,
	                   after_T02          NUMBER(5)          ,
                           brakeAfter_T02     CHAR(1) 		 ,
	                   after_T03          NUMBER(5)          ,
                           brakeAfter_T03     CHAR(1) 		 ,
	                   after_T04          NUMBER(5)          ,
                           brakeAfter_T04     CHAR(1) 		 ,
	                   after_T05          NUMBER(5)          ,
                           brakeAfter_T05     CHAR(1) 		 ,
	                   after_T06          NUMBER(5)          ,
                           brakeAfter_T06     CHAR(1) 		 ,
	                   after_T07          NUMBER(5)          ,
                           brakeAfter_T07     CHAR(1) 		 ,
	                   after_T08          NUMBER(5)          ,
                           brakeAfter_T08     CHAR(1) 		 ,
	                   after_T09          NUMBER(5)          ,
                           brakeAfter_T09     CHAR(1) 		 ,
	                   after_T10          NUMBER(5)          ,
                           brakeAfter_T10     CHAR(1) 		 ,
	                   after_T11          NUMBER(5)          ,
                           brakeAfter_T11     CHAR(1) 		 ,
	                   after_T12          NUMBER(5)          ,
                           brakeAfter_T12     CHAR(1) 		 ,
	                   after_T13          NUMBER(5)          ,
                           brakeAfter_T13     CHAR(1) 		 ,
	                   after_T14          NUMBER(5)          ,
                           brakeAfter_T14     CHAR(1) 		 ,
	                   after_T15          NUMBER(5)          ,
                           brakeAfter_T15     CHAR(1) 		 ,
	                   after_T16          NUMBER(5)          ,
                           brakeAfter_T16     CHAR(1) 		 ,
	                   after_T17          NUMBER(5)          ,
                           brakeAfter_T17     CHAR(1) 		 ,
	                   after_T18          NUMBER(5)          ,
                           brakeAfter_T18     CHAR(1) 		 ,
	                   after_T19          NUMBER(5)          ,
                           brakeAfter_T19     CHAR(1) 		 ,
	                   after_T20          NUMBER(5)          ,
                           brakeAfter_T20     CHAR(1) 		 ,
	                   latitude           FLOAT		 ,
	                   longitude          FLOAT		 ,
	                   PRIMARY KEY (locationID, driveRightID, accidentDateTime));

CREATE TABLE Days (locationID        NUMBER(5)  NOT NULL, 
                   driveRightID      NUMBER(5)  NOT NULL, 
                   dayDate           DATE       NOT NULL,
                   day               NUMBER(5)  NOT NULL, 
                   driverID          NUMBER(5)  NOT NULL, 
	           totalDistance     FLOAT              ,
	           highSpeed         NUMBER(5)          ,
	           timeOfHighSpeed   NUMBER(5)          ,
	           timeOverSpeed     NUMBER(5)          ,
	           totalTime         NUMBER(5)          ,
	           accelCount        NUMBER(5)          ,
	           decelCount        NUMBER(5)          ,
	           speedLimit        NUMBER(5)          ,
                   accelLimit        NUMBER(5)          ,
                   decelLimit        NUMBER(5)          ,
                   driveRightType    NUMBER(5)          ,
	           firstMove         NUMBER(5)          ,
	           lastMove          NUMBER(5)          ,
	           timeInMotion      NUMBER(5)          ,
	           highAccel         NUMBER(5)          ,
	           highAccelTime     NUMBER(5)          ,
  	           PRIMARY KEY (locationID, driveRightID, dayDate));

CREATE TABLE DownloadDates (locationID        NUMBER(5)  NOT NULL, 
                            driveRightID      NUMBER(5)  NOT NULL, 
                            downloadDate      DATE       NOT NULL,
                            daysSince         NUMBER(5)  NOT NULL, 
                            driverID          NUMBER(5)  NOT NULL, 
	                    PRIMARY KEY (locationID, driveRightID, downloadDate));

CREATE TABLE Password (locationID        NUMBER(5)  NOT NULL, 
                       userName          CHAR(40)   NOT NULL,
                       password          CHAR(40)   NOT NULL,
                       userType          CHAR(1)    NOT NULL,
                       driveRtAccess     CHAR(1)    NOT NULL,
	               drBackup          CHAR(1)            ,
	               drRestore         CHAR(1) 	    ,
	               drImport          CHAR(1) 	    ,
	               drExport          CHAR(1) 	    ,
	               drPreferences     CHAR(1) 	    ,
	               drMaintenance     CHAR(1) 	    ,
	               reports           CHAR(1) 	    ,
	               locations         CHAR(1) 	    ,
	               driveRights       CHAR(1) 	    ,
	               driverGroups      CHAR(1) 	    ,
	               drivers           CHAR(1) 	    ,
	               fleets            CHAR(1) 	    ,
	               vehicles          CHAR(1) 	    ,
	               trips             CHAR(1) 	    ,
	               accidentLogs      CHAR(1) 	    ,
	               tamperLogs        CHAR(1) 	    ,
	               addresses         CHAR(1) 	    ,
	               days              CHAR(1) 	    ,
	               downloadDates     CHAR(1) 	    ,
	               gps               CHAR(1) 	    ,
		       odometerLogs      CHAR(1) 	    ,
		       safetyScore       CHAR(1) 	    ,
	               PRIMARY KEY (userName));

CREATE TABLE GPS (locationID        NUMBER(5)  NOT NULL, 
                  driveRightID      NUMBER(5)  NOT NULL, 
                  gpsDateTime       DATE       NOT NULL,
                  day               NUMBER(5)          ,
                  driverID          NUMBER(5)          ,
	          speed		    NUMBER(5)          ,
	          direction	    FLOAT 	       ,
	          highSpeed         NUMBER(5)          ,
	          latitude          FLOAT 	       ,
	          longitude         FLOAT              ,
	          gpsStatus         INT                ,
	          vehicleState      CHAR(1)            ,
                  PRIMARY KEY (locationID, driveRightID, gpsDateTime));

CREATE TABLE OdometerLogs (locationID         NUMBER(5)  NOT NULL,
                           driveRightID       NUMBER(5)  NOT NULL,
  	                   adjustmentDateTime DATE       NOT NULL,
                           vehicleID          NUMBER(5)  NOT NULL,
                           odometerValue      FLOAT 	 NOT NULL,
	                   cause              CHAR(40)    	 ,
	                   PRIMARY KEY (locationID, driveRightID, adjustmentDateTime));


CREATE TABLE SafetyScore  (locationID         NUMBER(5)  NOT NULL,
                           driverID           NUMBER(5)  NOT NULL,
  							year               NUMBER(5)  NOT NULL,
                           month              NUMBER(5)  NOT NULL,                          
                           exemptDriver	      CHAR(1)		,
							score	         NUMBER(5)  	,
							mileage	         FLOAT  		,
							vehicleType        CHAR(1)    NOT NULL,
							recalcScore       CHAR(1)		, ;
							extraByte         CHAR(1)          , ;
							extraInt1         NUMBER(6)	         , ;
							extraInt2         NUMBER(6)	         , ;
							extraFloat        FLOAT			 , ;		   
	                   PRIMARY KEY (locationID, driverID, year, month, vehicleType));





































