
--********************************************************************************************
-- Copyright 2006-2008 Davis Instuments
--
-- This sql script will create all tables and stored procedures for MS SQLServer database 
-- needed by DriveRight software. It can be run through SQLServer OSQL command line program. 
-- Under DOS prompt type:
--		OSQL /E /S ENGSQLSERVER /d DRIVERIGHT_MSSQL /i DriveRight_MSSQL_Schema.sql /o DriveRight_DBConfig_MSSQL.log
--
-- Tables: (24)
--		ACCIDENTLOGS
--		CARCHIPS
--		CARCHIPPARAMETERS
--		COMPANYLOCATION
--		CONFIG
--		DAYS
--		DOWNLOADDATES
--		DRIVERGROUPS
--		DRIVERIGHTS
--		DRIVERS
--		EMAILLIST
--		FLEETS
--		GPS
--		ODOMETERLOGS
--		PASSWORD
--		READINESSCODES
--		SAFETYSCORE
--		TAMPERLOGS
--		TRIPADDRESSES
--		TRIPS
--		TROUBLECODES
--		VEHICLES
--		WIRELESSDEVICES
--		WIRELESSAUTODOWNLOADCFG
--
-- Stored Procedures or Functions: (23)
--		DR_INSERT_ACCIDENTLOG
--		DR_INSERT_CARCHIP
--		DR_INSERT_CARCHIPPARAMETER
--		DR_INSERT_COMPANYLOCATION
--		DR_INSERT_DAY
--		DR_INSERT_DOWNLOADDATE
--		DR_INSERT_DRIVER
--		DR_INSERT_DRIVERGROUP
--		DR_INSERT_DRIVERIGHT
--		DR_INSERT_FLEET
--		DR_INSERT_GPS
--		DR_INSERT_ODOMETERLOG
--		DR_INSERT_READINESSCODE
--		DR_INSERT_SAFETYSCORE
--		DR_INSERT_TAMPERLOG
--		DR_INSERT_TRIP
--		DR_INSERT_TRIPADDRESS
--		DR_INSERT_TROUBLECODE
--		DR_INSERT_VEHICLE
--		DR_INSERT_WIRELESSDEVICES
--		DR_INSERT_WLAUTODOWNLOADCFG
--		DR_UPDATE_WIRELESSDEVICES
--		DR_UPDATE_WLAUTODOWNLOADCFG
--
--
-- 04/06/2006 Susan Xie: Created based on WORD documents 
--			 msSQL_MSDE_TablesCreation.doc and DriveRight_StoredProcedures_SQLServer.doc
--			 and source file DriveRightDBCreator.cpp
-- 06/21/2006 Susan Xie: Added table WirelessDevices and AutoWLDownloadCfg and stored porcedures.
-- 11/06/2006 Susan Xie: Changed CarChip VehicleSpeed interval (interval 1) default from 5 to 1.
--						 Changed alarmState, LEDState defaults to 1.
-- 01/16/2007 Susan Xie: Added table CONFIG. This table can be used to save settings global to all db users. 
-- 02/23/2007 Susan Xie: dbo as owner to all tables and stored procedures.
-- 04/17/2007 Susan Xie: added corpStructure column to PASSWORD table.
-- 04/25/2007 Susan Xie: changed data type of CODE column in TROUBLECODES table to CHAR from NUMBER.
-- 07/12/2007 Susan Xie: added column DownloadConfig to CarChip table and updated stored procedure.
-- 08/29/2007 Susan Xie: added column DriveRightID to WirelessDevices table and updated stored procedures.
--				This is to support the wireless download for CC FleetPro assigned to Driver.
-- 09/20/2007 Susan Xie: added CarChipParameters table and stored procedure.
-- 02/27/2008 Susan Xie: added IdleTime column to Trips table.
-- 06/18/2008 Susan Xie: update database version to 3.9.1
-- 08/15/2008 Susan Xie: update database version to 3.9.2
-- 04/16/2009 Susan Xie: update database version to 3.9.3
--
--********************************************************************************************

------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------


PRINT ''
PRINT 'CREATE TABLES'

PRINT ''
PRINT 'Create Table AccidentLogs'

CREATE TABLE dbo.AccidentLogs (
			locationID         SMALLINT  NOT NULL, 
			driveRightID       SMALLINT  NOT NULL, 
			accidentDateTime   DATETIME  NOT NULL, 
			driverID           SMALLINT  NOT NULL, 
			realOrDecel        CHAR(1)   NOT NULL, 
			cause	          CHAR(1)	, 
			before_T19         SMALLINT	, 
			brakeBefore_T19	  CHAR(1)	, 
			before_T18         SMALLINT	, 
			brakeBefore_T18	  CHAR(1)	, 
			before_T17         SMALLINT	, 
			brakeBefore_T17    CHAR(1)	, 
			before_T16         SMALLINT	, 
			brakeBefore_T16    CHAR(1)	, 
			before_T15         SMALLINT	, 
			brakeBefore_T15    CHAR(1)	, 
			before_T14         SMALLINT	, 
			brakeBefore_T14    CHAR(1)	, 
			before_T13         SMALLINT	, 
			brakeBefore_T13    CHAR(1)	, 
			before_T12         SMALLINT	, 
			brakeBefore_T12    CHAR(1)	, 
			before_T11         SMALLINT	, 
			brakeBefore_T11    CHAR(1)	, 
			before_T10         SMALLINT	, 
			brakeBefore_T10    CHAR(1)	, 
			before_T09         SMALLINT	, 
			brakeBefore_T09    CHAR(1)	, 
			before_T08         SMALLINT	, 
			brakeBefore_T08    CHAR(1)	, 
			before_T07         SMALLINT	, 
			brakeBefore_T07    CHAR(1)	, 
			before_T06         SMALLINT	, 
			brakeBefore_T06    CHAR(1)	, 
			before_T05         SMALLINT	, 
			brakeBefore_T05    CHAR(1)	, 
			before_T04         SMALLINT	, 
			brakeBefore_T04    CHAR(1)	, 
			before_T03         SMALLINT	, 
			brakeBefore_T03    CHAR(1)	, 
			before_T02         SMALLINT	, 
			brakeBefore_T02    CHAR(1)	, 
			before_T01         SMALLINT	, 
			brakeBefore_T01    CHAR(1)	, 
			time_T0            SMALLINT	, 
			brakeAt_T0	  CHAR(1)	, 
			after_T01          SMALLINT	, 
			brakeAfter_T01     CHAR(1)	, 
			after_T02          SMALLINT	, 
			brakeAfter_T02     CHAR(1)	, 
			after_T03          SMALLINT	, 
			brakeAfter_T03     CHAR(1)	, 
			after_T04          SMALLINT	, 
			brakeAfter_T04     CHAR(1)	, 
			after_T05          SMALLINT	, 
			brakeAfter_T05     CHAR(1)	, 
			after_T06          SMALLINT	, 
			brakeAfter_T06     CHAR(1)	, 
			after_T07          SMALLINT	, 
			brakeAfter_T07     CHAR(1)	, 
			after_T08          SMALLINT	, 
			brakeAfter_T08     CHAR(1)	, 
			after_T09          SMALLINT	, 
			brakeAfter_T09     CHAR(1)	, 
			after_T10          SMALLINT	, 
			brakeAfter_T10     CHAR(1)	, 
			after_T11          SMALLINT	, 
			brakeAfter_T11     CHAR(1)	, 
			after_T12          SMALLINT	, 
			brakeAfter_T12     CHAR(1)	, 
			after_T13          SMALLINT	, 
			brakeAfter_T13     CHAR(1)	, 
			after_T14          SMALLINT	, 
			brakeAfter_T14     CHAR(1)	, 
			after_T15          SMALLINT	, 
			brakeAfter_T15     CHAR(1)	, 
			after_T16          SMALLINT	, 
			brakeAfter_T16     CHAR(1)	, 
			after_T17          SMALLINT	, 
			brakeAfter_T17     CHAR(1)	, 
			after_T18          SMALLINT	, 
			brakeAfter_T18     CHAR(1)	, 
			after_T19          SMALLINT	, 
			brakeAfter_T19     CHAR(1)	, 
			after_T20          SMALLINT	, 
			brakeAfter_T20     CHAR(1)	, 
			latitude           REAL		, 
			longitude          REAL		, 
			PRIMARY KEY (locationID, driveRightID, accidentDateTime) ); 

GO       
------------------------------------------------------------------------------------------ 
		
PRINT ''
PRINT 'Create Table CarChips'

CREATE TABLE dbo.CarChips (
		locationID        SMALLINT  NOT NULL, 
		carChipID         SMALLINT  NOT NULL, 
		serialNumber      CHAR(20)  NOT NULL, 
		carChipType       SMALLINT			, 
		vehicleID         SMALLINT			, 
		driverID          SMALLINT			, 
		speedBand1        SMALLINT			, 
		speedBand2        SMALLINT			, 
		speedBand3        SMALLINT			, 
		hardBraking       REAL			    , 
		extremeBraking    REAL			    , 
		hardAccel         REAL			    , 
		extremeAccel      REAL			    , 
		parameter1        SMALLINT			, 
		interval1         SMALLINT	    	, 
		parameter2        SMALLINT			, 
		interval2         SMALLINT			, 
		parameter3        SMALLINT			, 
		interval3         SMALLINT			, 
		parameter4        SMALLINT			, 
		interval4         SMALLINT			, 
		parameter5        SMALLINT			, 
		interval5         SMALLINT			, 
		alarmState        CHAR(1)			, 
		LEDState			CHAR(1)			, 
		downloadConfig   SMALLINT			,
		PRIMARY KEY (locationID, carChipID) );   
GO       
------------------------------------------------------------------------------------------
PRINT ''
PRINT 'Create Table CarChipParameters'

CREATE TABLE dbo.CarChipParameters  (
			locationID		SMALLINT   NOT NULL, 
			carChipID		SMALLINT   NOT NULL, 
			logType			SMALLINT	NOT NULL, 
			logDateTime		DATETIME	NOT NULL,
			logValue		REAL,
			PRIMARY KEY (locationID, carChipID, logType, logDateTime) );
GO 
------------------------------------------------------------------------------------------
		
PRINT ''
PRINT 'Create Table CompanyLocations'
       
CREATE TABLE dbo.CompanyLocations ( 
		locationID        SMALLINT   PRIMARY KEY,      				  
		locationName      CHAR(40)   NOT NULL,   
		locationAddress   CHAR(80)  , 
		parentLocationID  SMALLINT  ,
		levelNum  	  SMALLINT  ,
		extraField1       SMALLINT  ,
		extraField2       CHAR(40) );

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Table CONFIG'

CREATE TABLE dbo.CONFIG (CONFIG_KEY	VARCHAR(32) NOT NULL,
			CONFIG_VALUE VARCHAR(32) NOT NULL,
			PRIMARY KEY(CONFIG_KEY) );
			
GO
------------------------------------------------------------------------------------------			
PRINT ''
PRINT 'Create Table Days'
		
CREATE TABLE dbo.Days (
       locationID        SMALLINT  NOT NULL, 
       driveRightID      SMALLINT  NOT NULL, 
       dayDate           DATETIME  NOT NULL, 
       day               SMALLINT  NOT NULL, 
       driverID          SMALLINT  NOT NULL, 
       totalDistance     REAL		, 
       highSpeed         SMALLINT	, 
       timeOfHighSpeed   SMALLINT	, 
       timeOverSpeed     SMALLINT	, 
       totalTime         SMALLINT	, 
       accelCount        SMALLINT	, 
       decelCount        SMALLINT	, 
       speedLimit        SMALLINT	, 
       accelLimit        SMALLINT	, 
       decelLimit        SMALLINT	, 
       driveRightType    SMALLINT	, 
       firstMove         SMALLINT	, 
       lastMove          SMALLINT	, 
       timeInMotion      SMALLINT	, 
       highAccel         SMALLINT	, 
       highAccelTime     SMALLINT	, 
       PRIMARY KEY (locationID, driveRightID, dayDate) );
GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Table DownloadDates'

CREATE TABLE dbo.DownloadDates (
       locationID        SMALLINT  NOT NULL, 
       driveRightID      SMALLINT  NOT NULL, 
       downloadDate      DATETIME  NOT NULL, 
       daysSince         SMALLINT  NOT NULL, 
       driverID          SMALLINT  NOT NULL, 
       PRIMARY KEY (locationID, driveRightID, downloadDate) ); 
GO
------------------------------------------------------------------------------------------
PRINT ''
PRINT 'Create Table DriveRights'

CREATE TABLE dbo.DriveRights (
       locationID        SMALLINT  NOT NULL, 
       driveRightID      SMALLINT  NOT NULL, 
       vehicleID         SMALLINT	, 
       driveRightType    SMALLINT	, 
       speedLimit        SMALLINT	, 
       accelLimit        SMALLINT	, 
       decelLimit        SMALLINT	, 
       settingsCode      SMALLINT	, 
       stopTime          SMALLINT	, 
       logOutTime        SMALLINT	, 
       VSS               INT   		, 
       pulsesPerReading  SMALLINT	, 
       calibrationNumber INT   		, 
       distanceUnit      CHAR(1)	, 
       dateMode          CHAR(1)	, 
       timeMode          CHAR(1)	, 
       alarmMode         CHAR(1)	, 
       warnNotLogged     CHAR(1)	, 
       tamperLight       CHAR(1)	, 
       activeField	 CHAR(1)	, 
       remarks           CHAR(80)	, 
       PRIMARY KEY (locationID, driveRightID) ) ;   
GO
------------------------------------------------------------------------------------------
    
PRINT ''
PRINT 'Create Table DriveGroups'

CREATE TABLE dbo.DriverGroups (
       locationID        SMALLINT   NOT NULL, 
       groupNumber       SMALLINT   NOT NULL, 
       groupName         CHAR(60)   NOT NULL, 
       remarks           CHAR(60)	 , 
       PRIMARY KEY (locationID, groupNumber) );
GO
------------------------------------------------------------------------------------------
   
PRINT ''
PRINT 'Create Table Drivers'
       
CREATE TABLE dbo.Drivers (
       locationID        SMALLINT  NOT NULL, 
       driverID          SMALLINT  NOT NULL, 
       groupNumber       SMALLINT	   , 
       driverName        CHAR(60)  NOT NULL, 
       initials          CHAR(5)	, 
       address           CHAR(80)	, 
       city_state        CHAR(60)	, 
       zipCode           CHAR(20)	, 
       phoneNumber       CHAR(20)	, 
       email             CHAR(80)	, 
       companyName       CHAR(80)	, 
       employeeID        CHAR(15)	, 
       activeField	 CHAR(1)	, 
       remarks           CHAR(80)	, 
       PRIMARY KEY (locationID, driverID) );

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Table EmailList'
       
CREATE TABLE dbo.EmailList (
      locationID       SMALLINT  NOT NULL,
      entryID	       SMALLINT  NOT NULL,
      name	           CHAR(60)  NOT NULL,
      email            CHAR(80)	NOT NULL,
      remarks          CHAR(80)	,
      reportsList      CHAR(255),
	  PRIMARY KEY (locationID, entryID));
	  
GO
------------------------------------------------------------------------------------------
		
PRINT ''
PRINT 'Create Table Fleets'

CREATE TABLE dbo.Fleets (
       locationID        SMALLINT  NOT NULL, 
       fleetNumber       SMALLINT  NOT NULL, 
       fleetName         CHAR(40)  NOT NULL, 
       PRIMARY KEY (locationID, fleetNumber) );

GO  
------------------------------------------------------------------------------------------
		
PRINT ''
PRINT 'Create Table GPS'

CREATE TABLE dbo.GPS (
		locationID        SMALLINT  NOT NULL, 
		driveRightID      SMALLINT  NOT NULL, 
		gpsDateTime       DATETIME  NOT NULL, 
		day               SMALLINT	, 
		driverID          SMALLINT	, 
		speed	          SMALLINT	, 
		direction         REAL		, 
		highSpeed         SMALLINT	, 
		latitude          REAL		, 
		longitude         REAL		, 
		gpsStatus         INT   	, 
		vehicleState      CHAR(1)	, 
		PRIMARY KEY (locationID, driveRightID, gpsDateTime) );

GO  
------------------------------------------------------------------------------------------
		
PRINT ''
PRINT 'Create Table OdometerLogs'

CREATE TABLE dbo.OdometerLogs (
       locationID          SMALLINT  NOT NULL, 
       driveRightID        SMALLINT  NOT NULL, 
       adjustmentDateTime  DATETIME  NOT NULL, 
       vehicleID		SMALLINT  NOT NULL, 
       odometerValue       REAL      NOT NULL, 
       cause               CHAR(40), 
       PRIMARY KEY (locationID, driveRightID, adjustmentDateTime) ); 

GO  
------------------------------------------------------------------------------------------
		
PRINT ''
PRINT 'Create Table Password'

CREATE TABLE dbo.Password (
		locationID        SMALLINT  NOT NULL, 
		userName          CHAR(40)  NOT NULL, 
		password          CHAR(40)  NOT NULL, 
		userType	     CHAR(1)   NOT NULL, 
		driveRtAccess     CHAR(1)   NOT NULL, 
		drBackup          CHAR(1) , 
		drRestore         CHAR(1) , 
		drImport          CHAR(1) , 
		drExport          CHAR(1) , 
		drPreferences     CHAR(1) , 
		drMaintenance     CHAR(1) , 
		reports           CHAR(1) , 
		locations         CHAR(1) , 
		driveRights       CHAR(1) , 
		driverGroups      CHAR(1) , 
		drivers           CHAR(1) , 
		fleets            CHAR(1) , 	  	  
		vehicles          CHAR(1) , 	  
		trips             CHAR(1) , 
		accidentLogs      CHAR(1) , 
		tamperLogs        CHAR(1) , 
		addresses         CHAR(1) , 
		days              CHAR(1) , 
		downloadDates     CHAR(1) , 
		gps               CHAR(1) , 
		odometerLogs      CHAR(1) , 	  
		safetyScore       CHAR(1) , 
		corpStructure     CHAR(1) ,	
		PRIMARY KEY (userName) );

GO  
------------------------------------------------------------------------------------------
		
PRINT ''
PRINT 'Create Table ReadinessCodes'

CREATE TABLE dbo.ReadinessCodes (
		locationID		SMALLINT	NOT NULL, 
		carChipID		SMALLINT	NOT NULL, 
		codeDateTime	DATETIME	NOT NULL, 
		cmCode			SMALLINT	NOT NULL, 
		cmSupported		CHAR(1)		NOT NULL, 
		cmStatus		CHAR(1)		NOT NULL, 
		hcmCode			SMALLINT	NOT NULL, 
		hcmSupported	CHAR(1)		NOT NULL, 
		hcmStatus		CHAR(1)		NOT NULL, 
		esmCode			SMALLINT	NOT NULL, 
		esmSupported	CHAR(1)		NOT NULL, 
		esmStatus		CHAR(1)		NOT NULL, 
		sasmCode		SMALLINT	NOT NULL, 
		sasmSupported	CHAR(1)		NOT NULL, 
		sasmStatus		CHAR(1)		NOT NULL, 
		asrmCode		SMALLINT	NOT NULL, 
		asrmSupported	CHAR(1)		NOT NULL, 
		asrmStatus		CHAR(1)		NOT NULL, 
		osmCode			SMALLINT	NOT NULL, 
		osmSupported	CHAR(1)		NOT NULL, 
		osmStatus		CHAR(1)		NOT NULL, 
		oshmCode		SMALLINT	NOT NULL, 
		oshmSupported	CHAR(1)		NOT NULL, 
		oshmStatus		CHAR(1)		NOT NULL, 
		egrsmCode		SMALLINT	NOT NULL, 
		egrsmSupported	CHAR(1)		NOT NULL, 
		egrsmStatus		CHAR(1)		NOT NULL, 
		mfmCode			SMALLINT	NOT NULL, 
		mfmSupported	CHAR(1)		NOT NULL, 
		mfmStatus		CHAR(1)		NOT NULL, 
		fsmCode			SMALLINT	NOT NULL, 
		fsmSupported	CHAR(1)		NOT NULL, 
		fsmStatus		CHAR(1)		NOT NULL, 
		ccmCode			SMALLINT	NOT NULL, 
		ccmSupported	CHAR(1)		NOT NULL, 
		ccmStatus		CHAR(1)		NOT NULL, 
		PRIMARY KEY (locationID, carChipID, codeDateTime));

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Table SafetyScore'

CREATE TABLE dbo.SafetyScore  (
		locationID         SMALLINT  NOT NULL,
		driverID           SMALLINT  NOT NULL,
		year               SMALLINT  NOT NULL,
		month              SMALLINT  NOT NULL,
		exemptDriver	   CHAR(1),
		score				SMALLINT,
		mileage	      	   REAL,
		vehicleType           CHAR(1)   NOT NULL,
		recalcScore           CHAR(1), 
		extraByte             CHAR(1), 
		extraInt1             INT, 
		extraInt2             INT, 
		extraFloat            REAL, 
		PRIMARY KEY (locationID, driverID, year, month, vehicleType));

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Table TamperLogs'

CREATE TABLE dbo.TamperLogs (
       locationID        SMALLINT  NOT NULL, 
       driveRightID      SMALLINT  NOT NULL, 
       tamperDateTime    DATETIME  NOT NULL, 
       downloadDateTime  DATETIME	, 
       driverID          SMALLINT  NOT NULL, 
       cause             SMALLINT  NOT NULL, 
       PRIMARY KEY (locationID, driveRightID, tamperDateTime, cause) ); 

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Table TripAddresses'

CREATE TABLE dbo.TripAddresses (
       locationID        SMALLINT  NOT NULL, 
       addressID         SMALLINT  NOT NULL, 
       name              CHAR(80)  NOT NULL, 
       companyName       CHAR(40)	, 
       contactPerson     CHAR(40)	, 
       address           CHAR(80)	, 
       city              CHAR(40)	, 
       state             CHAR(40)	, 
       zipCode           CHAR(40)	, 
       country           CHAR(40)	, 
       telephone         CHAR(20)	, 
       fax               CHAR(20)	, 
       email             CHAR(80)	, 
       latitude          REAL		,  
       longitude         REAL		,  
       elevation         REAL		, 
       addressRadius     SMALLINT	,  
       ExtraStr          CHAR(80)	, 
       ExtraInt1         SMALLINT	, 
       ExtraInt2         SMALLINT	, 
       PRIMARY KEY (locationID, addressID) );  
GO       
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create dbo.Table Trips'

CREATE TABLE Trips (
       locationID        SMALLINT  NOT NULL, 
       driveRightID      SMALLINT  NOT NULL, 
       driverID          SMALLINT  NOT NULL, 
       startDateTime     DATETIME  NOT NULL, 
       endDateTime       DATETIME  NOT NULL, 
       tripTime          SMALLINT  NOT NULL, 
       distance          REAL      NOT NULL,       
       vehicleID         SMALLINT  NOT NULL,  
       averageSpeed      SMALLINT  NOT NULL,  
       topSpeed          SMALLINT  NOT NULL, 
       timeOverSpeed     INT       NOT NULL, 
       startOdometer     REAL      NOT NULL, 
       endOdometer       REAL      NOT NULL, 
       accelCount        SMALLINT  NOT NULL,  
       decelCount        SMALLINT  NOT NULL,  
       tripType          CHAR(1)   NOT NULL, 
       fromAddress       SMALLINT	,        
       toAddress         SMALLINT	,
       reason            CHAR(80)	, 
       startState        CHAR(1)	, 
       endState          CHAR(1)	, 
	   idleTime          INT,
       PRIMARY KEY (locationID, driveRightID, driverID, startDateTime) );
GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Table TroubleCodes'

CREATE TABLE dbo.TroubleCodes (
		locationID			SMALLINT		NOT NULL, 
		carChipID			SMALLINT		NOT NULL, 
		codeDateTime			DATETIME		NOT NULL, 
		code				CHAR(8)			NOT NULL, 	
		fuelPressure			REAL, 
		intakeManifoldPressure		REAL, 
		engineCoolantTemperature	REAL, 
		calculatedLoadValue		REAL, 
		engineSpeed			REAL, 
		vehicleSpeed			REAL, 
		shortTermFuelTripBankOne	REAL, 
		shortTermFuelTripBankTwo	REAL, 
		longTermFuelTripBankOne		REAL, 		
		longTermFuelTripBankTwo		REAL, 
		fuelSystemOneStatus		INT, 
		fuelSystemTwoStatus		INT, 
		comments			CHAR(80), 
		PRIMARY KEY (locationID, carChipID, codeDateTime));
GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Table Vehicles'

CREATE TABLE dbo.Vehicles (
       locationID        SMALLINT  NOT NULL, 
       vehicleID         SMALLINT  NOT NULL, 
       vehicleNumber     CHAR(80)	   , 
       fleetNumber       SMALLINT  NOT NULL, 
       driveRightID      SMALLINT  NOT NULL, 
       driverID          SMALLINT  NOT NULL, 
       make_model        CHAR(80)	, 
       licensePlate      CHAR(20)	, 
       color             CHAR(10)	, 
       purchaseDate      DATETIME	, 
       currentOdometer   REAL      NOT NULL, 
       vehicleType       SMALLINT	, 
       digitalInputs     CHAR(1)	, 
       activeField       CHAR(1)	, 
       remarks           CHAR(80)	, 
       PRIMARY KEY (locationID, vehicleID) );
GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Table WirelessDevices'

CREATE TABLE dbo.WirelessDevices (serialNumHigh 	BIGINT,
			serialNumLow 		BIGINT,
			locationID      	SMALLINT NOT NULL,
			PANID      		SMALLINT NOT NULL,
			deviceType   		TINYINT NOT NULL,
			baseStationPos  	VARCHAR(32),
			USBSerialNum  		VARCHAR(16),
			vehicleID       	SMALLINT,
			autoDownload    	TINYINT,
			lastDownloadStatus    	TINYINT,
			driveRightID      	SMALLINT,
			PRIMARY KEY (serialNumHigh, serialNumLow));

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Table WirelessAutoDownloadCfg'

CREATE TABLE dbo.WirelessAutoDownloadCfg (
			PANID      	SMALLINT CONSTRAINT pK_wirelessAutoDownloadCfg PRIMARY KEY,
			startTime   	DATETIME NOT NULL,
			duration  	TINYINT NOT NULL,
			includeWeekend  TINYINT NOT NULL);

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT ''
PRINT 'CREATE STORED PROCEDURES'

PRINT ''
PRINT 'Create Stored Procedure dr_insert_accidentLog '
-- we need this GO to end a sql batch so that CREATE PROCEDURE will be the first statement of next batch
GO 

CREATE PROCEDURE dbo.dr_insert_accidentLog 
	@field1 smallint,@field2 smallint,
	@field3 datetime,@field4 smallint,
	@field5 char(1),@field6 char(1),
	@field7 smallint,@field8 char(1),
	@field9 smallint,@field10 char(1),
	@field11 smallint,@field12 char(1),
	@field13 smallint,@field14 char(1),
	@field15 smallint,@field16 char(1),
	@field17 smallint,@field18 char(1),
	@field19 smallint,@field20 char(1),
	@field21 smallint,@field22 char(1),
	@field23 smallint,@field24 char(1),
	@field25 smallint,@field26 char(1),
	@field27 smallint,@field28 char(1),
	@field29 smallint,@field30 char(1),
	@field31 smallint,@field32 char(1),
	@field33 smallint,@field34 char(1),
	@field35 smallint,@field36 char(1),
	@field37 smallint,@field38 char(1),
	@field39 smallint,@field40 char(1),
	@field41 smallint,@field42 char(1),
	@field43 smallint,@field44 char(1),
	@field45 smallint,@field46 char(1),
	@field47 smallint,@field48 char(1),
	@field49 smallint,@field50 char(1),
	@field51 smallint,@field52 char(1),
	@field53 smallint,@field54 char(1),
	@field55 smallint,@field56 char(1),
	@field57 smallint,@field58 char(1),
	@field59 smallint,@field60 char(1),
	@field61 smallint,@field62 char(1),
	@field63 smallint,@field64 char(1),
	@field65 smallint,@field66 char(1),
	@field67 smallint,@field68 char(1),
	@field69 smallint,@field70 char(1),
	@field71 smallint,@field72 char(1),
	@field73 smallint,@field74 char(1),
	@field75 smallint,@field76 char(1),
	@field77 smallint,@field78 char(1),
	@field79 smallint,@field80 char(1),
	@field81 smallint,@field82 char(1),
	@field83 smallint,@field84 char(1),
	@field85 smallint,@field86 char(1),
	@field87 real,@field88 real
AS 
BEGIN
	SET NOCOUNT ON
	INSERT INTO ACCIDENTLOGS VALUES (@field1,@field2,@field3,@field4,@field5,@field6,
		@field7,@field8,@field9,@field10,@field11,@field12,@field13,@field14,
		@field15,@field16,@field17,@field18,@field19,@field20,@field21,
		@field22,@field23,@field24,@field25,@field26,@field27,
		@field28,@field29,@field30,@field31,@field32,@field33,@field34,@field35,
		@field36,@field37,@field38,@field39,@field40,@field41,@field42,
		@field43,@field44,@field45,@field46,@field47,@field48,
		@field49,@field50,@field51,@field52,@field53,@field54,@field55,@field56,
		@field57,@field58,@field59,@field60,@field61,@field62,@field63,
		@field64,@field65,@field66,@field67,@field68,@field69,
		@field70,@field71,@field72,@field73,@field74,@field75,@field76,@field77,
		@field78,@field79,@field80,@field81,@field82,@field83,@field84,
		@field85,@field86,@field87,@field88);
END

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Stored Procedure dr_insert_carChip '
-- we need this GO to end a sql batch so that CREATE PROCEDURE will be the first statement of next batch
GO 

CREATE PROCEDURE dbo.dr_insert_carChip 
	@field1 smallint, @field2 smallint, @field3 char(20), @field4 smallint, @field5 smallint, 
	@field6 smallint, @field7 smallint, @field8 smallint, @field9 smallint, @field10 real, 
	@field11 real, @field12 real, @field13 real, @field14 smallint, @field15 smallint, 
	@field16 smallint, @field17 smallint, @field18 smallint, @field19 smallint, @field20 smallint, 
	@field21 smallint , @field22 smallint, @field23 smallint , @field24 char(1), @field25 char(1), @field26 smallint 
AS 
BEGIN
	SET NOCOUNT ON 
	INSERT INTO CARCHIPS VALUES (@field1, @field2, @field3, @field4, @field5, @field6, @field7, 
		@field8, @field9, @field10, @field11, @field12, @field13, @field14, @field15, @field16, @field17, 
		@field18, @field19, @field20, @field21, @field22, @field23, @field24, @field25, @field26);
END

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Stored Procedure dr_insert_carChipParameter'
-- we need this GO to end a sql batch so that CREATE PROCEDURE will be the first statement of next batch
GO 

CREATE PROCEDURE dbo.dr_insert_carChipParameter 
	@field1 smallint, @field2 smallint, @field3 smallint, @field4 datetime, @field5 real 
AS 
BEGIN
	SET NOCOUNT ON 
	INSERT INTO CARCHIPPARAMETERS ( LOCATIONID, CARCHIPID, LOGTYPE, LOGDATETIME, LOGVALUE)
	VALUES (@field1, @field2, @field3, @field4, @field5);
END

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Stored Procedure dr_insert_companyLocation'
-- we need this GO to end a sql batch so that CREATE PROCEDURE will be the first statement of next batch
GO 

CREATE PROCEDURE dbo.dr_insert_companyLocation 
	@field1 smallint, @field2 char(40), @field3 char(80), 
	@field4 smallint, @field5 smallint, @field6 smallint, @field7 char(40)
AS 
BEGIN
	SET NOCOUNT ON 
	INSERT INTO COMPANYLOCATIONS VALUES (@field1, @field2, @field3, @field4, @field5, @field6, @field7);
END

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Stored Procedure dr_insert_day'
-- we need this GO to end a sql batch so that CREATE PROCEDURE will be the first statement of next batch
GO 

CREATE PROCEDURE dbo.dr_insert_day 
	@field1 smallint,@field2 smallint,
	@field3 datetime,@field4 smallint,
	@field5 smallint,@field6 real,
	@field7 smallint,@field8 smallint,
	@field9 smallint,@field10 smallint,
	@field11 smallint,@field12 smallint,
	@field13 smallint,@field14 smallint,
	@field15 smallint,@field16 smallint,
	@field17 smallint,@field18 smallint,
	@field19 smallint,@field20 smallint,
	@field21 smallint
AS 
BEGIN
	SET NOCOUNT ON 
	INSERT INTO DAYS VALUES (@field1,@field2,@field3,@field4,@field5,@field6,
		@field7,@field8,@field9,@field10,@field11,@field12,
		@field13,@field14,@field15,@field16,@field17,@field18,
		@field19,@field20,@field21);
END

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Stored Procedure dr_insert_downloadDate'
-- we need this GO to end a sql batch so that CREATE PROCEDURE will be the first statement of next batch
GO 

CREATE PROCEDURE dbo.dr_insert_downloadDate 
	@field1 smallint, @field2 smallint, @field3 datetime, 
	@field4 smallint, @field5 smallint
AS 
BEGIN
	SET NOCOUNT ON 
	INSERT INTO DOWNLOADDATES VALUES (@field1, @field2, @field3, @field4, @field5);
END

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Stored Procedure dr_insert_driverGroup'
-- we need this GO to end a sql batch so that CREATE PROCEDURE will be the first statement of next batch
GO 

CREATE PROCEDURE dbo.dr_insert_driverGroup 
	@field1 smallint, @field2 smallint, 
	@field3 char(60), @field4 char(60)
AS 
BEGIN
	SET NOCOUNT ON
	INSERT INTO DRIVERGROUPS VALUES (@field1, @field2, @field3, @field4);
END

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Stored Procedure dr_insert_driveRight'
-- we need this GO to end a sql batch so that CREATE PROCEDURE will be the first statement of next batch
GO
 
CREATE PROCEDURE dbo.dr_insert_driveRight 
	@field1 smallint, @field2 smallint, @field3 smallint, @field4 smallint, @field5 smallint,  
	@field6 smallint, @field7 smallint, @field8 smallint, @field9 smallint, @field10 smallint, 
	@field11 int, @field12 smallint, @field13 int, @field14 char(1), @field15 char(1),
	@field16 char(1), @field17 char(1), @field18 char(1), @field19 char(1), @field20 char(1), @field21 char(80) 
AS 
BEGIN
	SET NOCOUNT ON 
	INSERT INTO DRIVERIGHTS VALUES (@field1, @field2, @field3, @field4, @field5, 
		@field6, @field7, @field8, @field9, @field10, 
		@field11, @field12, @field13, @field14, @field15, 
		@field16, @field17, @field18, @field19, @field20, @field21);
END

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Stored Procedure dr_insert_driver'
-- we need this GO to end a sql batch so that CREATE PROCEDURE will be the first statement of next batch
GO 

CREATE PROCEDURE dbo.dr_insert_driver 
	@field1 smallint, @field2 smallint, @field3 smallint, @field4 char(60), @field5 char(5),
	@field6 char(80), @field7 char(60), @field8 char(20), @field9 char(20),@field10 char(80), 
	@field11 char(80), @field12 char(15), @field13 char(1), @field14 char(80)
AS 
BEGIN
	SET NOCOUNT ON 
	INSERT INTO DRIVERS VALUES (@field1, @field2, @field3, @field4, @field5, 
		@field6, @field7, @field8, @field9, @field10, 
		@field11, @field12, @field13, @field14);
END

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Stored Procedure dr_insert_fleet'
-- we need this GO to end a sql batch so that CREATE PROCEDURE will be the first statement of next batch
GO 

CREATE PROCEDURE dbo.dr_insert_fleet 
@field1 smallint, @field2 smallint, @field3 char(40)
AS 
BEGIN
	SET NOCOUNT ON 
	INSERT INTO FLEETS VALUES (@field1, @field2, @field3);
END

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Stored Procedure dr_insert_gps'
-- we need this GO to end a sql batch so that CREATE PROCEDURE will be the first statement of next batch
GO 

CREATE PROCEDURE dbo.dr_insert_gps 
	@field1 smallint,@field2 smallint,@field3 datetime,@field4 smallint,@field5 smallint, 
	@field6 smallint, @field7 real, @field8 smallint, @field9 real, @field10 real, @field11 int, @field12 char(1)
AS 
BEGIN
	SET NOCOUNT ON
	INSERT INTO GPS VALUES (@field1,@field2,@field3,@field4,@field5,
		@field6,@field7,@field8,@field9,@field10,@field11,@field12);
END

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Stored Procedure dr_insert_odometerLog'
-- we need this GO to end a sql batch so that CREATE PROCEDURE will be the first statement of next batch
GO 

CREATE PROCEDURE dbo.dr_insert_odometerLog 
	@field1 smallint,@field2 smallint,@field3 datetime,
	@field4 smallint,@field5 real, @field6 char(40)
AS 
BEGIN
	SET NOCOUNT ON
	INSERT INTO ODOMETERLOGS VALUES (@field1,@field2,@field3,@field4,@field5, @field6);
END

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Stored Procedure dr_insert_readinessCode'
-- we need this GO to end a sql batch so that CREATE PROCEDURE will be the first statement of next batch
GO 

CREATE PROCEDURE dbo.dr_insert_readinessCode 
	@field1 smallint,@field2 smallint,@field3 datetime,@field4 smallint,@field5 char(1),
	@field6 char(1),@field7 smallint,@field8 char(1),@field9 char(1),@field10 smallint,
	@field11 char(1),@field12 char(1),@field13 smallint,@field14 char(1),@field15 char(1),
	@field16 smallint,@field17 char(1),@field18 char(1),@field19 smallint,@field20 char(1),
	@field21 char(1),@field22 smallint,@field23 char(1),@field24 char(1),@field25 smallint,
	@field26 char(1),@field27 char(1) ,@field28 smallint,@field29 char(1),@field30 char(1),
	@field31 smallint,@field32 char(1),@field33 char(1),@field34 smallint,@field35 char(1),
	@field36 char(1)
AS
BEGIN
	SET NOCOUNT ON
	INSERT INTO READINESSCODES VALUES (@field1,@field2,@field3,@field4, @field5, 
		@field6,@field7, @field8, @field9,@field10, 
		@field11, @field12,@field13, @field14, @field15,
		@field16, @field17, @field18,@field19, @field20, 
		@field21,@field22, @field23, @field24,@field25, 
		@field26, @field27,@field28, @field29, @field30,
		@field31, @field32, @field33,@field34, @field35, 
		@field36);
END

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Stored Procedure dr_insert_safetyScore'
-- we need this GO to end a sql batch so that CREATE PROCEDURE will be the first statement of next batch
GO 

CREATE PROCEDURE dbo.dr_insert_safetyScore 
	@field1 smallint,@field2 smallint,@field3 smallint,
	@field4 smallint,@field5 char(1), @field6 smallint,
	@field7 real, @field8 char(1)
AS 
BEGIN
	SET NOCOUNT ON 
	INSERT INTO SAFETYSCORE (locationID, driverID, year, month, exemptDriver, score, mileage, vehicleType)  
	VALUES (@field1,@field2,@field3,@field4,@field5,@field6,@field7, @field8);
END

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Stored Procedure dr_insert_tamperLog'
-- we need this GO to end a sql batch so that CREATE PROCEDURE will be the first statement of next batch
GO 

CREATE PROCEDURE dbo.dr_insert_tamperLog 
	@field1 smallint,@field2 smallint,@field3 datetime,
	@field4 datetime,@field5 smallint,@field6 smallint
AS 
BEGIN
	SET NOCOUNT ON 
	INSERT INTO TAMPERLOGS VALUES (@field1,@field2,@field3,@field4,@field5,@field6);
END

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Stored Procedure dr_insert_trip'
-- we need this GO to end a sql batch so that CREATE PROCEDURE will be the first statement of next batch
GO 

CREATE PROCEDURE dbo.dr_insert_trip 
	@field1 smallint,@field2 smallint,@field3 smallint,@field4 datetime,@field5 datetime,
	@field6 smallint,@field7 real,@field8 smallint,@field9 smallint,@field10 smallint,
	@field11 int,@field12 real,@field13 real,@field14 smallint,@field15 smallint,
	@field16 char(1),@field17 smallint,@field18 smallint,@field19 char(80),@field20 char(1),
	@field21 char(1), @field22 int
AS 
BEGIN
	SET NOCOUNT ON
	INSERT INTO TRIPS VALUES (@field1,@field2,@field3,@field4,@field5,@field6,
		@field7,@field8,@field9,@field10,@field11,@field12,@field13,@field14,
		@field15,@field16,@field17,@field18,@field19,@field20,@field21,@field22);
END

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Stored Procedure dr_insert_tripAddress'
-- we need this GO to end a sql batch so that CREATE PROCEDURE will be the first statement of next batch
GO 

CREATE PROCEDURE dbo.dr_insert_tripAddress 
	@field1 smallint, @field2 smallint, @field3 char(80), @field4 char(40), @field5 char(40),
	@field6 char(80), @field7 char(40), @field8 char(40), @field9 char(40), @field10 char(40), 
	@field11 char(20), @field12 char(20), @field13 char(80), @field14 real, @field15 real, 
	@field16 real, @field17 smallint, @field18 char(80), @field19 smallint, @field20 smallint
AS 
BEGIN
	SET NOCOUNT ON 
	INSERT INTO TRIPADDRESSES VALUES (@field1, @field2, @field3, @field4, @field5, 
		@field6, @field7, @field8, @field9, @field10, 
		@field11, @field12, @field13, @field14, @field15, 
		@field16, @field17, @field18, @field19, @field20);
END

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Stored Procedure dr_insert_troubleCode'
-- we need this GO to end a sql batch so that CREATE PROCEDURE will be the first statement of next batch
GO 

CREATE PROCEDURE dbo.dr_insert_troubleCode 
	@field1 smallint,@field2 smallint,@field3 datetime,@field4 char(8), @field5 int, @field6 int, 
	@field7 real, @field8 real, @field9 real, @field10 real, @field11 real, @field12 real, 
	@field13 real, @field14 real, @field15 real, @field16 real, @field17 char(80)
AS
	BEGIN
	SET NOCOUNT ON
	INSERT INTO TROUBLECODES VALUES (@field1, @field2, @field3, @field4, @field5, @field6, 
		@field7, @field8, @field9, @field10, @field11, @field12, 
		@field13, @field14, @field15, @field16, @field17);
END

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Stored Procedure dr_insert_vehicle'
-- we need this GO to end a sql batch so that CREATE PROCEDURE will be the first statement of next batch
GO 

CREATE PROCEDURE dbo.dr_insert_vehicle 
	@field1 smallint, @field2 smallint, @field3 char(80), @field4 smallint, @field5 smallint, 
	@field6 smallint, @field7 char(80), @field8 char(20), @field9 char(10), @field10 datetime, 
	@field11 real, @field12 smallint, @field13 char(1), @field14 char(1), @field15 char(80) 
AS 
BEGIN
	SET NOCOUNT ON
	INSERT INTO VEHICLES VALUES (@field1, @field2, @field3, @field4, @field5, 
		@field6, @field7, @field8, @field9, @field10, 
		@field11, @field12, @field13, @field14, @field15);
END

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Stored Procedure dr_insert_wirelessDevices'
-- we need this GO to end a sql batch so that CREATE PROCEDURE will be the first statement of next batch
GO 

CREATE PROCEDURE dbo.dr_insert_wirelessDevices
			@in_serialNumHigh 	BIGINT,
			@in_serialNumLow	BIGINT,
			@in_locationID      	SMALLINT,
			@in_PANID      		SMALLINT,
			@in_deviceType   	TINYINT,
			@in_baseStationPos	VARCHAR(32) = NULL,
			@in_USBSerialNum	VARCHAR(16) = NULL,
			@in_vehicleID       	SMALLINT = NULL,
			@in_autoDownload    	TINYINT = NULL,
			@in_lastDownloadStatus 	TINYINT = NULL,
			@in_driveRightID       	SMALLINT = NULL
AS
BEGIN
	SET NOCOUNT ON
	INSERT INTO WIRELESSDEVICES ( SERIALNUMHIGH, SERIALNUMLOW, LOCATIONID, PANID, DEVICETYPE,
				 BASESTATIONPOS, USBSERIALNUM, VEHICLEID, AUTODOWNLOAD, LASTDOWNLOADSTATUS, DRIVERIGHTID) 
		VALUES( @in_serialNumHigh,
			@in_serialNumLow,
			@in_locationID,
			@in_PANID,
			@in_deviceType,
			@in_baseStationPos,
			@in_USBSerialNum,
			@in_vehicleID,
			@in_autoDownload,
			@in_lastDownloadStatus,
			@in_driveRightID);
END

GO

------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Stored Procedure dr_update_wirelessDevices'
-- we need this GO to end a sql batch so that CREATE PROCEDURE will be the first statement of next batch
GO 

CREATE PROCEDURE dbo.dr_update_wirelessDevices
			@in_serialNumHigh	BIGINT,
			@in_serialNumLow	BIGINT,
			@in_baseStationPos  	VARCHAR(32),
			@in_USBSerialNum  		VARCHAR(16),
			@in_vehicleID       	SMALLINT,
			@in_autoDownload    	TINYINT,
			@in_lastDownloadStatus 	TINYINT,
			@in_driveRightID 	SMALLINT
AS
BEGIN
	SET NOCOUNT ON
	UPDATE WIRELESSDEVICES 
	SET baseStationPos = @in_baseStationPos,
		USBSerialNum = @in_USBSerialNum,
		vehicleID = @in_vehicleID,
		autoDownload = @in_autoDownload,
		lastDownloadStatus = @in_lastDownloadStatus,
		driveRightID = @in_driveRightID
	WHERE serialNumHigh = @in_serialNumHigh AND serialNumLow = @in_serialNumLow;
END

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Stored Procedure dr_insert_wlAutoDownloadCfg'
-- we need this GO to end a sql batch so that CREATE PROCEDURE will be the first statement of next batch
GO 

CREATE PROCEDURE dbo.dr_insert_wlAutoDownloadCfg
			@in_PANID		SMALLINT,
			@in_startTime		DATETIME,
			@in_duration      	TINYINT,
			@in_includeWeekend 	TINYINT
AS
BEGIN
	SET NOCOUNT ON
	INSERT INTO WirelessAutoDownloadCfg (PANID, STARTTIME, DURATION, INCLUDEWEEKEND)
		VALUES(@in_PANID, @in_startTime, @in_duration, @in_includeWeekend);
END

GO
------------------------------------------------------------------------------------------

PRINT ''
PRINT 'Create Stored Procedure dr_update_wlAutoDownloadCfg'
-- we need this GO to end a sql batch so that CREATE PROCEDURE will be the first statement of next batch
GO 

CREATE PROCEDURE dbo.dr_update_wlAutoDownloadCfg
			@in_PANID		SMALLINT,
			@in_startTime		DATETIME,
			@in_duration      	TINYINT,
			@in_includeWeekend 	TINYINT
AS
BEGIN
	SET NOCOUNT ON
	UPDATE WirelessAutoDownloadCfg 
	SET startTime = @in_startTime,
		duration = @in_duration,
		includeWeekend = @in_includeWeekend
	WHERE PANID = @in_PANID;
END

GO
------------------------------------------------------------------------------------------

--****************************************************************************************

PRINT ''
PRINT ''
PRINT 'Initialize tables with default values'
PRINT ''

INSERT INTO Fleets(locationID, fleetNumber, fleetName)
	VALUES (1, 0, 'Default Fleet');

INSERT INTO DriverGroups(locationID, groupNumber, groupName)
	VALUES (1, 0, 'Default Group');

INSERT INTO DriveRights(locationID, driveRightID, vehicleID, driveRightType, speedLimit,
		accelLimit, decelLimit, settingsCode, stopTime, logOutTime,
		VSS, pulsesPerReading, calibrationNumber, distanceUnit, dateMode,
		timeMode,  alarmMode, warnNOTLogged, tamperLight)
   	VALUES (1, 0, 0, 0, 65, 30, 35, 0, 10, 0, 0, 0, 0, 2, 4, 0, 0, 0, 0); 	

INSERT INTO CarChips(locationID, carChipID, serialNumber, carChipType, vehicleID, driverID, speedBand1, 
		speedBand2, speedBand3, hardBraking, extremeBraking, hardAccel, extremeAccel,
		parameter1, interval1, parameter2, interval2, parameter3, interval3,
		parameter4, interval4, parameter5, interval5, alarmState, LEDState, downloadConfig)
	VALUES (1, 0, '0', 0, 0, 0, 45, 60, 70, 3.4323275, 4.903325, 2.941995, 4.4129925, 1, 1, 2, 5, 4, 5, 0, 5, 0, 5, 1, 1, 1); 	

INSERT INTO Drivers(locationID, driverID, groupNumber, driverName)
	VALUES (1, 0, 0, 'Unknown Driver (None)');

INSERT INTO Vehicles(locationID, vehicleID, vehicleNumber, fleetNumber, driveRightID, driverID, currentOdometer)
	VALUES (1, 0, 0, 0, 0, 0, 0);

--This version number needs to be updated for each release.

INSERT INTO CONFIG(CONFIG_KEY, CONFIG_VALUE)
	VALUES ('DB_VERSION', '3.9.3');

------------------------------------------------------------------------------------------

PRINT ''
PRINT ''
PRINT 'MS SQL SERVER Schema Creation Complete.'
PRINT ''
GO

-- Statistic Information
-- 
PRINT ''
PRINT ''
SELECT CONFIG_VALUE DATABASE_VERSION FROM CONFIG WHERE CONFIG_KEY = 'DB_VERSION';
GO

PRINT ''
PRINT ''
PRINT 'Tables:'
PRINT ''
SELECT LEFT(NAME,30) AS TABLE_NAME FROM SYSOBJECTS WHERE TYPE = 'U' ORDER BY NAME;
GO

PRINT ''
PRINT ''
PRINT 'Stored Procedures:'
PRINT ''
SELECT LEFT(NAME,30) AS PROCEDURE_NAME FROM SYSOBJECTS WHERE TYPE = 'P' AND NAME LIKE 'dr_%' ORDER BY NAME;
GO

