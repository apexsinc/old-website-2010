--********************************************************************************************
-- Copyright 2006-2008 Davis Instuments
--
-- This sql script will create all tables and stored procedures for Oracle database needed by 
-- DriveRight software. It can be run through Oracle SQLPLUS command line program. 
-- Under DOS prompt type:
--	sqlplus DR36/DR36@dright.davisnet.com @DriveRight_Oracle_Schema.sql DriveRight_DBConfig_Oracle.log
--
-- Tables: (24)
--		ACCIDENTLOGS
--		CARCHIPS
--		CARCHIPPARAMETERS
--		COMPANYLOCATION
--		CONFIG
--		DAYS
--		DOWNLOADDATES
--		DRIVERGROUPS
--		DRIVERIGHTS
--		DRIVERS
--		EMAILLIST
--		FLEETS
--		GPS
--		ODOMETERLOGS
--		PASSWORD
--		READINESSCODES
--		SAFETYSCORE
--		TAMPERLOGS
--		TRIPADDRESSES
--		TRIPS
--		TROUBLECODES
--		VEHICLES
--		WIRELESSDEVICES
--		WIRELESSAUTODOWNLOADCFG
--
-- Stored Procedures: (23)
--		DR_INSERT_ACCIDENTLOG
--		DR_INSERT_CARCHIP
--		DR_INSERT_CARCHIPPARAMETER
--		DR_INSERT_COMPANYLOCATI
--		DR_INSERT_DAY
--		DR_INSERT_DOWNLOADDATE
--		DR_INSERT_DRIVER
--		DR_INSERT_DRIVERGROUP
--		DR_INSERT_DRIVERIGHT
--		DR_INSERT_FLEET
--		DR_INSERT_GPS
--		DR_INSERT_ODOMETERLOG
--		DR_INSERT_READINESSCODE
--		DR_INSERT_SAFETYSCORE
--		DR_INSERT_TAMPERLOG
--		DR_INSERT_TRIP
--		DR_INSERT_TRIPADDRESS
--		DR_INSERT_TROUBLECODE
--		DR_INSERT_VEHICLE
--		DR_INSERT_WIRELESSDEVICES
--		DR_INSERT_WLAUTODOWNLOADCFG
--		DR_UPDATE_WIRELESSDEVICES
--		DR_UPDATE_WLAUTODOWNLOADCFG
--
--
-- 04/05/2006 Susan Xie: Created based on WORD documents 
--			 oracle_TablesCreation.doc and DriveRight_StoredProcedures_ORACLE.doc
--			 and source file DriveRightDBCreator.cpp
-- 06/21/2006 Susan Xie: Added table WirelessDevices and AutoWLDownloadCfg and stored porcedures.
-- 10/05/2006 Susan Xie: Update stored procedure dr_insert_safetyscore to remove the last 5 columns. 
-- 11/06/2006 Susan Xie: Changed CarChip VehicleSpeed interval (interval 1) default from 5 to 1.
--						 Changed alarmState, LEDState defaults to 1.
-- 01/16/2007 Susan Xie: Added table CONFIG. This table can be used to save settings global to all db users. 
-- 04/17/2007 Susan Xie: added corpStructure column to PASSWORD table.
-- 04/25/2007 Susan Xie: changed data type of CODE column in TROUBLECODES table to VARCHAR2 from NUMBER.
-- 07/12/2007 Susan Xie: added column DownloadConfig to CarChip table and updated stored procedure.
-- 08/29/2007 Susan Xie: added column DriveRightID to WirelessDevices table and updated stored procedures.
--				This is to support the wireless download for CC FleetPro assigned to Driver.
-- 09/20/2007 Susan Xie: added CarChipParameters table and stored procedure.
-- 02/27/2008 Susan Xie: added IdleTime column to Trips table.
-- 06/18/2008 Susan Xie: update database version to 3.9.1
-- 08/15/2008 Susan Xie: update database version to 3.9.2
-- 04/16/2009 Susan Xie: update database version to 3.9.3
--
--********************************************************************************************

SET TERMOUT  OFF

SPOOL &1 

PROMPT *** CREATE DRIVERIGHT FMS ORACLE SCHEMA ***
PROMPT

SHOW USER

--********************************************************************************************
--
-- Tables
--
--********************************************************************************************

PROMPT
PROMPT *** CREATE TABLES ***
PROMPT
PROMPT Create Table AccidentLogs 
CREATE TABLE AccidentLogs (locationID      NUMBER(5)  NOT NULL, 
			driveRightID       NUMBER(5)  NOT NULL,
			accidentDateTime   DATE       NOT NULL,
			driverID           NUMBER(5)  NOT NULL,
			realOrDecel        CHAR(1)    NOT NULL,
			cause	      	   CHAR(1),
			before_T19         NUMBER(5),
			brakeBefore_T19    CHAR(1),
			before_T18         NUMBER(5),
			brakeBefore_T18    CHAR(1),
			before_T17         NUMBER(5),
			brakeBefore_T17    CHAR(1),
			before_T16         NUMBER(5),
			brakeBefore_T16    CHAR(1),
			before_T15         NUMBER(5),
			brakeBefore_T15    CHAR(1),
			before_T14         NUMBER(5),
			brakeBefore_T14    CHAR(1),
			before_T13         NUMBER(5),
			brakeBefore_T13    CHAR(1),
			before_T12         NUMBER(5),
			brakeBefore_T12    CHAR(1),
			before_T11         NUMBER(5),
			brakeBefore_T11    CHAR(1),
			before_T10         NUMBER(5),
			brakeBefore_T10    CHAR(1),
			before_T09         NUMBER(5),
			brakeBefore_T09    CHAR(1),
			before_T08         NUMBER(5),
			brakeBefore_T08    CHAR(1),
			before_T07         NUMBER(5),
			brakeBefore_T07    CHAR(1),
			before_T06         NUMBER(5),
			brakeBefore_T06    CHAR(1),
			before_T05         NUMBER(5),
			brakeBefore_T05    CHAR(1),
			before_T04         NUMBER(5),
			brakeBefore_T04    CHAR(1),
			before_T03         NUMBER(5),
			brakeBefore_T03    CHAR(1),
			before_T02         NUMBER(5),
			brakeBefore_T02    CHAR(1),
			before_T01         NUMBER(5),
			brakeBefore_T01    CHAR(1),
			time_T0            NUMBER(5),
			brakeAt_T0	   CHAR(1),
			after_T01          NUMBER(5),
			brakeAfter_T01     CHAR(1),
			after_T02          NUMBER(5),
			brakeAfter_T02     CHAR(1),
			after_T03          NUMBER(5),
			brakeAfter_T03     CHAR(1),
			after_T04          NUMBER(5),
			brakeAfter_T04     CHAR(1),
			after_T05          NUMBER(5),
			brakeAfter_T05     CHAR(1),
			after_T06          NUMBER(5),
			brakeAfter_T06     CHAR(1),
			after_T07          NUMBER(5),
			brakeAfter_T07     CHAR(1),
			after_T08          NUMBER(5),
			brakeAfter_T08     CHAR(1),
			after_T09          NUMBER(5),
			brakeAfter_T09     CHAR(1),
			after_T10          NUMBER(5),
			brakeAfter_T10     CHAR(1),
			after_T11          NUMBER(5),
			brakeAfter_T11     CHAR(1),
			after_T12          NUMBER(5),
			brakeAfter_T12     CHAR(1),
			after_T13          NUMBER(5),
			brakeAfter_T13     CHAR(1),
			after_T14          NUMBER(5),
			brakeAfter_T14     CHAR(1),
			after_T15          NUMBER(5),
			brakeAfter_T15     CHAR(1),
			after_T16          NUMBER(5),
			brakeAfter_T16     CHAR(1),
			after_T17          NUMBER(5),
			brakeAfter_T17     CHAR(1),
			after_T18          NUMBER(5),
			brakeAfter_T18     CHAR(1),
			after_T19          NUMBER(5),
			brakeAfter_T19     CHAR(1),
			after_T20          NUMBER(5),
			brakeAfter_T20     CHAR(1),
			latitude           FLOAT,
			longitude          FLOAT,
			PRIMARY KEY (locationID, driveRightID, accidentDateTime));

------------------------------------------------------------------------------------------

PROMPT Create Table CarChips 
CREATE TABLE CarChips (
			locationID        NUMBER(5)   NOT NULL, 
			carChipID         NUMBER(5)   NOT NULL, 
			serialNumber      CHAR(20)    NOT NULL, 
			carChipType       NUMBER(5), 
			vehicleID         NUMBER(5), 
			driverID          NUMBER(5), 
			speedBand1        NUMBER(5), 
			speedBand2        NUMBER(5), 
			speedBand3        NUMBER(5), 
			hardBraking       FLOAT, 
			extremeBraking    FLOAT, 
			hardAccel         FLOAT, 
			extremeAccel      FLOAT, 
			parameter1        NUMBER(5), 
			interval1         NUMBER(5), 
			parameter2        NUMBER(5), 
			interval2         NUMBER(5), 
			parameter3        NUMBER(5), 
			interval3         NUMBER(5), 
			parameter4        NUMBER(5), 
			interval4         NUMBER(5), 
			parameter5        NUMBER(5), 
			interval5         NUMBER(5), 
			alarmState        CHAR(1), 
			LEDState	  CHAR(1),
			downloadConfig   NUMBER(5), 
			PRIMARY KEY (locationID, carChipID) );

------------------------------------------------------------------------------------------

PROMPT Create Table CarChipParameters 
CREATE TABLE CarChipParameters  (
			locationID		NUMBER(5)   NOT NULL, 
			carChipID		NUMBER(5)   NOT NULL, 
			logType			NUMBER(5)	NOT NULL, 
			logDateTime		DATE		NOT NULL,
			logValue		FLOAT,
			PRIMARY KEY (locationID, carChipID, logType, logDateTime) );

------------------------------------------------------------------------------------------

PROMPT Create Table CompanyLocations
CREATE TABLE CompanyLocations (locationID        NUMBER(5) PRIMARY KEY, 
			locationName      CHAR(40)  NOT NULL,
			locationAddress   CHAR(80)  ,
			parentLocationID  NUMBER(5) ,
			levelNum  	  NUMBER(5) ,
			extraField1       NUMBER(5) ,
			extraField2       CHAR(40) );
			       
------------------------------------------------------------------------------------------
			 
PROMPT Create Table CONFIG
CREATE TABLE CONFIG (CONFIG_KEY	VARCHAR(32) NOT NULL,
			CONFIG_VALUE VARCHAR(32) NOT NULL,
			PRIMARY KEY(CONFIG_KEY) );
			       
------------------------------------------------------------------------------------------

PROMPT Create Table Days
CREATE TABLE Days (locationID        NUMBER(5)  NOT NULL, 
				driveRightID      NUMBER(5)  NOT NULL, 
				dayDate           DATE       NOT NULL,
				day               NUMBER(5)  NOT NULL, 
				driverID          NUMBER(5)  NOT NULL, 
				totalDistance     FLOAT,
				highSpeed         NUMBER(5),
				timeOfHighSpeed   NUMBER(5),
				timeOverSpeed     NUMBER(5),
				totalTime         NUMBER(5),
				accelCount        NUMBER(5),
				decelCount        NUMBER(5),
				speedLimit        NUMBER(5),
				accelLimit        NUMBER(5),
				decelLimit        NUMBER(5),
				driveRightType    NUMBER(5),
				firstMove         NUMBER(5),
				lastMove          NUMBER(5),
				timeInMotion      NUMBER(5),
				highAccel         NUMBER(5),
				highAccelTime     NUMBER(5),
				PRIMARY KEY (locationID, driveRightID, dayDate));
				
------------------------------------------------------------------------------------------				

PROMPT Create Table DownloadDates
CREATE TABLE DownloadDates (locationID        NUMBER(5)  NOT NULL, 
			driveRightID      NUMBER(5)  NOT NULL, 
			downloadDate      DATE       NOT NULL,
			daysSince         NUMBER(5)  NOT NULL, 
			driverID          NUMBER(5)  NOT NULL, 
			PRIMARY KEY (locationID, driveRightID, downloadDate));

------------------------------------------------------------------------------------------

PROMPT Create Table Drivers 
CREATE TABLE Drivers (locationID          NUMBER(5)  NOT NULL, 
			driverID          NUMBER(5)  NOT NULL, 
			groupNumber       NUMBER(5), 
			driverName        CHAR(60)   NOT NULL,
			initials          CHAR(5),
			address           CHAR(80),
			city_state        CHAR(60),
			zipCode           CHAR(20),
			phoneNumber       CHAR(20),
			email             CHAR(80),
			companyName       CHAR(80),
			employeeID        CHAR(15),
			activeField	  CHAR(1),
			remarks           CHAR(80),
			PRIMARY KEY (locationID, driverID));



-------------------------------------------------------------------------------------------------

PROMPT Create Table DriverGroups
CREATE TABLE DriverGroups (
			locationID       NUMBER(5)  NOT NULL, 
			groupNumber      NUMBER(5)  NOT NULL, 
			groupName        CHAR(60)   NOT NULL, 
			remarks          CHAR(60), 
			PRIMARY KEY (locationID, groupNumber));

-------------------------------------------------------------------------------------------------

PROMPT Create Table DriveRights
CREATE TABLE DriveRights (
			locationID        NUMBER(5)  NOT NULL, 
			driveRightID      NUMBER(5)  NOT NULL, 
			vehicleID         NUMBER(5),
			driveRightType    NUMBER(5),
			speedLimit        NUMBER(5),
			accelLimit        NUMBER(5),
			decelLimit        NUMBER(5),
			settingsCode      NUMBER(5),
			stopTime          NUMBER(5),
			logOutTime        NUMBER(5),
			VSS               NUMBER(6),
			pulsesPerReading  NUMBER(5),
			calibrationNumber NUMBER(6),
			distanceUnit      CHAR(1),
			dateMode          CHAR(1),
			timeMode          CHAR(1),
			alarmMode         CHAR(1),
			warnNotLogged     CHAR(1),
			tamperLight       CHAR(1),
			activeField	  CHAR(1),
			remarks           CHAR(80),	
			PRIMARY KEY (locationID, driveRightID) );

-------------------------------------------------------------------------------------------------

PROMPT Create Table EmailList
CREATE TABLE EmailList(
			locationID        NUMBER(5)  NOT NULL,
			entryID           NUMBER(5)  NOT NULL,
			name		  CHAR(60)   NOT NULL,
			email             CHAR(80)   NOT NULL,
			remarks           CHAR(80),
			reportsList       CHAR(255),
			PRIMARY KEY (locationID, entryID));

-------------------------------------------------------------------------------------------------

PROMPT Create Table Fleets 
CREATE TABLE Fleets (locationID        NUMBER(5)  NOT NULL, 
			fleetNumber    NUMBER(5)  NOT NULL, 
			fleetName      CHAR(40)   NOT NULL,
			PRIMARY KEY (locationID, fleetNumber));

-------------------------------------------------------------------------------------------------

PROMPT Create Table GPS
CREATE TABLE GPS (locationID        NUMBER(5)  NOT NULL, 
			driveRightID      NUMBER(5)  NOT NULL, 
			gpsDateTime       DATE       NOT NULL,
			day               NUMBER(5),
			driverID          NUMBER(5),
			speed		  NUMBER(5),
			direction	  FLOAT,
			highSpeed         NUMBER(5),
			latitude          FLOAT,
			longitude         FLOAT,
			gpsStatus         INT,
			vehicleState      CHAR(1),
			PRIMARY KEY (locationID, driveRightID, gpsDateTime));

-------------------------------------------------------------------------------------------------

PROMPT Create Table OdometerLogs
CREATE TABLE OdometerLogs (locationID         NUMBER(5)  NOT NULL,
			driveRightID       NUMBER(5)  NOT NULL,
			adjustmentDateTime DATE       NOT NULL,
			vehicleID          NUMBER(5)  NOT NULL,
			odometerValue      FLOAT      NOT NULL,
			cause              CHAR(40)    	 ,
			PRIMARY KEY (locationID, driveRightID, adjustmentDateTime));

-------------------------------------------------------------------------------------------------

PROMPT Create Table Password
CREATE TABLE Password (locationID        NUMBER(5)  NOT NULL, 
			userName          CHAR(40)   NOT NULL,
			password          CHAR(40)   NOT NULL,
			userType          CHAR(1)    NOT NULL,
			driveRtAccess     CHAR(1)    NOT NULL,
			drBackup          CHAR(1)            ,
			drRestore         CHAR(1) 	    ,
			drImport          CHAR(1) 	    ,
			drExport          CHAR(1) 	    ,
			drPreferences     CHAR(1) 	    ,
			drMaintenance     CHAR(1) 	    ,
			reports           CHAR(1) 	    ,
			locations         CHAR(1) 	    ,
			driveRights       CHAR(1) 	    ,
			driverGroups      CHAR(1) 	    ,
			drivers           CHAR(1) 	    ,
			fleets            CHAR(1) 	    ,
			vehicles          CHAR(1) 	    ,
			trips             CHAR(1) 	    ,
			accidentLogs      CHAR(1) 	    ,
			tamperLogs        CHAR(1) 	    ,
			addresses         CHAR(1) 	    ,
			days              CHAR(1) 	    ,
			downloadDates     CHAR(1) 	    ,
			gps               CHAR(1) 	    ,
			odometerLogs      CHAR(1) 	    ,
			safetyScore       CHAR(1) 	    ,
			corpStructure     CHAR(1) 	    ,
			PRIMARY KEY (userName));

-------------------------------------------------------------------------------------------------

PROMPT Create Table ReadinessCodes
CREATE TABLE ReadinessCodes (
          locationID			NUMBER(5)	NOT NULL, 
          carChipID			NUMBER(5)	NOT NULL, 
	  codeDateTime			DATE		NOT NULL, 
	  cmCode			NUMBER(5)	NOT NULL, 
	  cmSupported			CHAR(1)		NOT NULL, 
	  cmStatus			CHAR(1)		NOT NULL, 
	  hcmCode			NUMBER(5)	NOT NULL, 
	  hcmSupported			CHAR(1)		NOT NULL, 
	  hcmStatus			CHAR(1)		NOT NULL, 
	  esmCode			NUMBER(5)	NOT NULL, 
	  esmSupported			CHAR(1)		NOT NULL, 
	  esmStatus			CHAR(1)		NOT NULL, 
	  sasmCode			NUMBER(5)	NOT NULL, 
	  sasmSupported			CHAR(1)		NOT NULL, 
	  sasmStatus			CHAR(1)		NOT NULL, 
	  asrmCode			NUMBER(5)	NOT NULL, 
	  asrmSupported			CHAR(1)		NOT NULL, 
	  asrmStatus			CHAR(1)		NOT NULL, 
	  osmCode			NUMBER(5)	NOT NULL, 
	  osmSupported			CHAR(1)		NOT NULL, 
	  osmStatus			CHAR(1)		NOT NULL, 
	  oshmCode			NUMBER(5)	NOT NULL, 
	  oshmSupported			CHAR(1)		NOT NULL,
	  oshmStatus			CHAR(1)		NOT NULL, 
	  egrsmCode			NUMBER(5)	NOT NULL, 
	  egrsmSupported		CHAR(1)		NOT NULL, 
	  egrsmStatus			CHAR(1)		NOT NULL, 
	  mfmCode			NUMBER(5)	NOT NULL, 
	  mfmSupported			CHAR(1)		NOT NULL, 
	  mfmStatus			CHAR(1)		NOT NULL, 
	  fsmCode			NUMBER(5)	NOT NULL, 
	  fsmSupported			CHAR(1)		NOT NULL, 
	  fsmStatus			CHAR(1)		NOT NULL, 
	  ccmCode			NUMBER(5)	NOT NULL, 
	  ccmSupported			CHAR(1)		NOT NULL, 
	  ccmStatus			CHAR(1)		NOT NULL, 
	  PRIMARY KEY (locationID, carChipID, codeDateTime));
	  
-------------------------------------------------------------------------------------------------

PROMPT Create Table SafetyScore
CREATE TABLE SafetyScore  (locationID      NUMBER(5)  NOT NULL,
			driverID           NUMBER(5)  NOT NULL,
			year               NUMBER(5)  NOT NULL,
			month              NUMBER(5)  NOT NULL, 
			exemptDriver	   CHAR(1),
			score	           NUMBER(5),
			mileage	           FLOAT,
			vehicleType        CHAR(1)    NOT NULL,
			recalcScore       CHAR(1), 
			extraByte         CHAR(1), 
			extraInt1         NUMBER(6), 
			extraInt2         NUMBER(6), 
			extraFloat        FLOAT, 		   
			PRIMARY KEY (locationID, driverID, year, month, vehicleType));

-------------------------------------------------------------------------------------------------

PROMPT Create Table TamperLogs
CREATE TABLE TamperLogs (locationID        NUMBER(5)  NOT NULL, 
			driveRightID      NUMBER(5)  NOT NULL, 
			tamperDateTime    DATE       NOT NULL,
			downloadDateTime  DATE,
			driverID          NUMBER(5)  NOT NULL, 
			cause             NUMBER(5)  NOT NULL, 
			PRIMARY KEY (locationID, driveRightID, tamperDateTime, cause));

-------------------------------------------------------------------------------------------------

PROMPT Create Table Trips
CREATE TABLE Trips (locationID        NUMBER(5)  NOT NULL, 
			driveRightID      NUMBER(5)  NOT NULL, 
			driverID          NUMBER(5)  NOT NULL, 
			startDateTime     DATE       NOT NULL,
			endDateTime       DATE       NOT NULL,
			tripTime          NUMBER(5)  NOT NULL, 
			distance          FLOAT      NOT NULL, 
			vehicleID         NUMBER(5)  NOT NULL, 
			averageSpeed      NUMBER(5)  NOT NULL, 
			topSpeed          NUMBER(5)  NOT NULL, 
			timeOverSpeed     NUMBER(6)  NOT NULL, 
			startOdometer     FLOAT      NOT NULL,
			endOdometer       FlOAT      NOT NULL,
			accelCount        NUMBER(5)  NOT NULL, 
			decelCount        NUMBER(5)  NOT NULL, 
			tripType          CHAR(1)    NOT NULL,
			fromAddress       NUMBER(5), 
			toAddress         NUMBER(5), 
			reason            CHAR(80),
			startState        CHAR(1),
			endState          CHAR(1),
			idleTime          NUMBER(6), 
			PRIMARY KEY (locationID, driveRightID, driverID, startDateTime));

-------------------------------------------------------------------------------------------------

PROMPT Create Table TripAddresses
CREATE TABLE TripAddresses (
			locationID        NUMBER(5)  NOT NULL, 
			addressID         NUMBER(5)  NOT NULL, 
			name              CHAR(80)   NOT NULL,
			companyName       CHAR(40),
			contactPerson     CHAR(40),
			address           CHAR(80),
			city              CHAR(40),
			state             CHAR(40),
			zipCode           CHAR(40),
			country           CHAR(40),
			telephone         CHAR(20),
			fax               CHAR(20),
			email             CHAR(80),
			latitude          FLOAT,
			longitude         FLOAT,
			elevation         FLOAT,
			addressRadius     NUMBER(5), 
			ExtraStr          CHAR(80),
			ExtraInt1         NUMBER(5),
			ExtraInt2         NUMBER(5),
			PRIMARY KEY (locationID, addressID));

-------------------------------------------------------------------------------------------------

PROMPT Create Table TroubleCodes
CREATE TABLE TroubleCodes (
		locationID			NUMBER(5)  NOT NULL, 
		carChipID			NUMBER(5)  NOT NULL, 
		codeDateTime			DATE       NOT NULL, 
		code				VARCHAR2(8)  NOT NULL, 
		fuelPressure			FLOAT, 
		intakeManifoldPressure		FLOAT, 
		engineCoolantTemperature	FLOAT, 
		calculatedLoadValue		FLOAT, 
		engineSpeed			FLOAT, 
		vehicleSpeed			FLOAT, 
		shortTermFuelTripBankOne	FLOAT, 		
		shortTermFuelTripBankTwo	FLOAT, 
		longTermFuelTripBankOne		FLOAT, 
		longTermFuelTripBankTwo		FLOAT, 	
		fuelSystemOneStatus		NUMBER(6), 
		fuelSystemTwoStatus		NUMBER(6), 
		comments			CHAR(80), 
		PRIMARY KEY (locationID, carChipID, codeDateTime));

-------------------------------------------------------------------------------------------------

PROMPT Create Table Vehicles 
CREATE TABLE Vehicles (locationID        NUMBER(5)  NOT NULL, 
			vehicleID         NUMBER(5)  NOT NULL, 
			vehicleNumber     CHAR(80)	    ,
			fleetNumber       NUMBER(5)  NOT NULL, 
			driveRightID      NUMBER(5)  NOT NULL, 
			driverID          NUMBER(5)  NOT NULL, 
			make_model        CHAR(80),
			licensePlate      CHAR(20),
			color             CHAR(10),
			purchaseDate      DATE,                       
			currentOdometer   FLOAT      NOT NULL,
			vehicleType       NUMBER(5),
			digitalInputs     CHAR(1), 
			activeField	 CHAR(1),
			remarks           CHAR(80),
			PRIMARY KEY (locationID, vehicleID));

-------------------------------------------------------------------------------------------------

PROMPT Create Table WirelessDevices
CREATE TABLE WirelessDevices (serialNumHigh	NUMBER(10),
			serialNumLow		NUMBER(10),
			locationID      	NUMBER(5) NOT NULL,
			PANID      			NUMBER(5) NOT NULL,
			deviceType   		NUMBER(3) NOT NULL,
			baseStationPos  	VARCHAR2(32),
			USBSerialNum  		VARCHAR2(16),
			vehicleID       	NUMBER(5),
			autoDownload    	NUMBER(3),
			lastDownloadStatus    	NUMBER(3),
			driveRightID		NUMBER(5),
			PRIMARY KEY (serialNumHigh, serialNumLow));
	
-------------------------------------------------------------------------------------------------		

PROMPT Create Table WirelessAutoDownloadCfg
CREATE TABLE WirelessAutoDownloadCfg (
			PANID      	NUMBER(5) CONSTRAINT pK_wirelessAutoDownloadCfg PRIMARY KEY,
			startTime   DATE NOT NULL,
			duration  	NUMBER(3) NOT NULL,
			includeWeekend  NUMBER(3) NOT NULL);
			
-------------------------------------------------------------------------------------------------

--***********************************************************************************************
--
-- Stored Procedures
--
--***********************************************************************************************

PROMPT
PROMPT *** CREATE STORED PROCEDURES ***
PROMPT

PROMPT Create Stored Procedure dr_insert_accidentLog
CREATE OR REPLACE PROCEDURE dr_insert_accidentLog (
			field1	IN	NUMBER,	field2	IN	NUMBER,	field3	IN	DATE,
			field4	IN	NUMBER,	field5	IN	CHAR,	field6	IN	CHAR,
			field7	IN 	NUMBER,	field8	IN	CHAR, 	field9	IN 	NUMBER,
			field10	IN	CHAR, 	field11	IN 	NUMBER,	field12	IN	CHAR, 
			field13	IN 	NUMBER,	field14	IN	CHAR, 	field15	IN 	NUMBER,
			field16	IN	CHAR,	field17 IN 	NUMBER,	field18	IN	CHAR, 
			field19	IN 	NUMBER,	field20	IN	CHAR, 	field21	IN 	NUMBER,
			field22	IN	CHAR, 	field23	IN 	NUMBER,	field24	IN	CHAR, 
			field25	IN 	NUMBER,	field26	IN	CHAR, 	field27	IN 	NUMBER,
			field28	IN	CHAR, 	field29	IN 	NUMBER,	field30	IN	CHAR, 
			field31	IN 	NUMBER,	field32	IN	CHAR, 	field33	IN 	NUMBER,
			field34	IN	CHAR, 	field35	IN 	NUMBER,	field36	IN	CHAR, 
			field37	IN 	NUMBER,	field38	IN	CHAR, 	field39	IN 	NUMBER,
			field40	IN	CHAR, 	field41	IN 	NUMBER,	field42	IN	CHAR, 
			field43	IN 	NUMBER,	field44	IN	CHAR, 	field45	IN 	NUMBER,
			field46	IN	CHAR, 	field47	IN 	NUMBER,	field48	IN	CHAR,
			field49	IN 	NUMBER,	field50	IN	CHAR, 	field51	IN 	NUMBER,
			field52	IN	CHAR, 	field53	IN 	NUMBER,	field54	IN	CHAR, 
			field55	IN 	NUMBER,	field56	IN	CHAR, 	field57	IN 	NUMBER,
			field58	IN	CHAR, 	field59	IN 	NUMBER,	field60	IN	CHAR, 
			field61	IN 	NUMBER,	field62	IN	CHAR, 	field63	IN 	NUMBER,
			field64	IN	CHAR, 	field65	IN 	NUMBER,	field66	IN	CHAR, 
			field67	IN 	NUMBER,	field68	IN	CHAR, 	field69	IN 	NUMBER,
			field70	IN	CHAR, 	field71	IN 	NUMBER,	field72	IN	CHAR, 
			field73	IN 	NUMBER,	field74	IN	CHAR, 	field75	IN 	NUMBER,
			field76	IN	CHAR, 	field77	IN 	NUMBER,	field78	IN	CHAR, 
			field79	IN 	NUMBER,	field80	IN	CHAR, 	field81	IN 	NUMBER,
			field82	IN	CHAR, 	field83	IN 	NUMBER,	field84	IN	CHAR,
			field85	IN 	NUMBER, field86	IN	CHAR,
			field87	IN 	REAL,	field88	IN	REAL ) AS

BEGIN
	INSERT INTO ACCIDENTLOGS VALUES (field1, field2, field3, field4, field5, field6,
		field7, field8, field9, field10, field11, field12, field13, field14,
		field15, field16, field17, field18, field19, field20, field21,
		field22, field23, field24, field25, field26, field27, field28,
		field29, field30, field31, field32, field33, field34, field35,
		field36, field37, field38, field39, field40, field41, field42,
		field43, field44, field45, field46, field47, field48, field49,
		field50, field51, field52, field53, field54, field55, field56,
		field57, field58, field59, field60, field61, field62, field63,
		field64, field65, field66, field67, field68, field69, field70,
		field71, field72, field73, field74, field75, field76, field77,
		field78, field79, field80, field81, field82, field83, field84,
		field85, field86, field87, field88);
	COMMIT;
END;
/

-------------------------------------------------------------------------------------------------

PROMPT Create Procedure dr_insert_carChip
CREATE OR REPLACE PROCEDURE dr_insert_carChip(
			field1	IN	NUMBER,
			field2	IN	NUMBER,
			field3	IN	CHAR,
			field4	IN	NUMBER,
			field5	IN	NUMBER,
			field6	IN	NUMBER,
			field7	IN	NUMBER,
			field8	IN	NUMBER,
			field9	IN	NUMBER,
			field10	IN	FLOAT,
			field11	IN	FLOAT,
			field12	IN	FLOAT,
			field13	IN	FLOAT,
			field14	IN	NUMBER,
			field15	IN	NUMBER,
			field16	IN	NUMBER,
			field17	IN	NUMBER,
			field18	IN	NUMBER,
			field19	IN	NUMBER,
			field20	IN	NUMBER,
			field21	IN	NUMBER,
			field22	IN	NUMBER,
			field23	IN	NUMBER,
			field24	IN	CHAR,
			field25	IN	CHAR,
			field26	IN	NUMBER)AS
BEGIN
	INSERT INTO CARCHIPS VALUES (field1,field2,field3,field4,field5,field6, field7,field8,field9,
		field10,field11,field12, field13,field14,field15,field16,field17,field18,
		field19, field20, field21, field22, field23, field24, field25, field26);
	COMMIT;
END;
/

------------------------------------------------------------------------------------------

PROMPT Create Procedure dr_insert_carChipParameter
CREATE OR REPLACE PROCEDURE dr_insert_carChipParameter(
			in_locationID	IN	NUMBER,
			in_carChipID	IN	NUMBER,
			in_logType		IN	NUMBER,
			in_logDateTime	IN	DATE,
			in_logValue		IN	FLOAT)AS
BEGIN
	INSERT INTO CARCHIPPARAMETERS( LOCATIONID, CARCHIPID, LOGTYPE, LOGDATETIME, LOGVALUE)
	VALUES (in_locationID, in_carChipID, in_logType, in_logDateTime, in_logValue);
	COMMIT;
END;
/

------------------------------------------------------------------------------------------

PROMPT Create procedure dr_insert_companyLocation
CREATE OR REPLACE PROCEDURE dr_insert_companyLocation(
			field1	IN	NUMBER,
			field2	IN	CHAR,
			field3	IN	CHAR,
			field4	IN	NUMBER,
			field5	IN	NUMBER,
			field6	IN	NUMBER,
			field7	IN	CHAR)AS
BEGIN
	INSERT INTO COMPANYLOCATIONS VALUES (field1, field2, field3, field4, field5, field6, field7);
	COMMIT;
END;
/

-----------------------------------------------------------------------------------------

PROMPT Create procedure dr_insert_day
CREATE OR REPLACE PROCEDURE dr_insert_day(
			field1	IN	NUMBER,
			field2	IN	NUMBER,
			field3	IN	DATE,
			field4	IN	NUMBER,
			field5	IN	NUMBER,
			field6	IN	FLOAT,
			field7	IN	NUMBER,
			field8	IN	NUMBER,
			field9	IN	NUMBER,
			field10	IN	NUMBER,
			field11	IN	NUMBER,
			field12	IN	NUMBER,
			field13	IN	NUMBER,
			field14	IN	NUMBER,
			field15	IN	NUMBER,
			field16	IN	NUMBER,
			field17	IN	NUMBER,
			field18	IN	NUMBER,
			field19	IN	NUMBER,
			field20	IN	NUMBER,
			field21	IN	NUMBER)AS
BEGIN
	INSERT INTO DAYS VALUES (field1,field2,field3,field4,field5,field6,field7,field8,field9,
		field10,field11,field12, field13,field14,field15,field16,field17,field18,field19,field20,field21);
	COMMIT;
END;
/

------------------------------------------------------------------------------------------

PROMPT Create procedure dr_insert_downloadDate
CREATE OR REPLACE PROCEDURE dr_insert_downloadDate(
			field1	IN	NUMBER,
			field2	IN	NUMBER,
			field3	IN	DATE,
			field4	IN	NUMBER,
			field5	IN	NUMBER)AS
BEGIN
	INSERT INTO DOWNLOADDATES VALUES (field1, field2, field3, field4, field5);
	COMMIT;
END;
/

------------------------------------------------------------------------------------------

PROMPT Create procedure dr_insert_driver
CREATE OR REPLACE PROCEDURE dr_insert_driver(
			field1	IN	NUMBER,
			field2	IN	NUMBER,
			field3	IN	NUMBER,
			field4	IN	CHAR,
			field5	IN	CHAR,
			field6	IN	CHAR,
			field7	IN	CHAR,
			field8	IN	CHAR,
			field9	IN	CHAR,
			field10	IN	CHAR,
			field11	IN	CHAR,
			field12	IN	CHAR,
			field13	IN	CHAR,
			field14	IN	CHAR)AS
BEGIN
	INSERT INTO DRIVERS VALUES (field1,field2,field3,field4,field5,field6, field7,field8,field9,
			field10,field11,field12, field13,field14);
	COMMIT;
END;
/

-------------------------------------------------------------------------------------------------

PROMPT Create procedure dr_insert_driverGroup
CREATE OR REPLACE PROCEDURE dr_insert_driverGroup(
			field1	IN	NUMBER,
			field2	IN	NUMBER,
			field3	IN	CHAR,
			field4	IN	CHAR)AS
BEGIN
	INSERT INTO DRIVERGROUPS VALUES (field1, field2, field3, field4);
COMMIT;
END;
/

-------------------------------------------------------------------------------------------------

PROMPT Create procedure dr_insert_driveRight
CREATE OR REPLACE PROCEDURE dr_insert_driveRight(
			field1	IN	NUMBER,
			field2	IN	NUMBER,
			field3	IN	NUMBER,
			field4	IN	NUMBER,
			field5	IN	NUMBER,
			field6	IN	NUMBER,
			field7	IN	NUMBER,
			field8	IN	NUMBER,
			field9	IN	NUMBER,
			field10	IN	NUMBER,
			field11	IN	NUMBER,
			field12	IN	NUMBER,
			field13	IN	NUMBER,
			field14	IN	CHAR,
			field15	IN	CHAR,
			field16	IN	CHAR,
			field17	IN	CHAR,
			field18	IN	CHAR,
			field19	IN	CHAR,
			field20	IN	CHAR,
			field21	IN	CHAR)AS
BEGIN
	INSERT INTO DRIVERIGHTS VALUES (field1,field2,field3,field4,field5,field6, field7,field8,field9,
			field10,field11,field12,field13,field14,field15,field16,field17,field18,field19,field20,field21);
COMMIT;
END;
/

-------------------------------------------------------------------------------------------------

PROMPT Create procedure dr_insert_fleet
CREATE OR REPLACE PROCEDURE dr_insert_fleet(
			field1	IN	NUMBER,
			field2	IN	NUMBER,
			field3	IN	CHAR)AS
BEGIN
	INSERT INTO FLEETS VALUES (field1, field2, field3);
COMMIT;
END;
/

-------------------------------------------------------------------------------------------------

PROMPT Create procedure dr_insert_gps
CREATE OR REPLACE PROCEDURE dr_insert_gps(
			field1	IN	NUMBER,
			field2	IN	NUMBER,
			field3	IN	DATE,
			field4	IN	NUMBER,
			field5	IN	NUMBER,
			field6	IN	NUMBER,
			field7	IN	FLOAT,
			field8	IN	NUMBER,
			field9	IN	FLOAT,
			field10	IN	FLOAT,
			field11	IN	INT,
			field12	IN	CHAR)AS
BEGIN

	INSERT INTO GPS VALUES (field1, field2, field3, field4, field5,
		field6, field7, field8, field9, field10, field11, field12);
COMMIT;
END;
/

-------------------------------------------------------------------------------------------------

PROMPT Create procedure OdometerLogs
CREATE OR REPLACE PROCEDURE dr_insert_odometerLog(
			field1	IN	NUMBER,
			field2	IN	NUMBER,
			field3	IN	DATE,
			field4	IN	NUMBER,
			field5	IN	FLOAT,
			field6	IN	CHAR)AS
BEGIN
	INSERT INTO ODOMETERLOGS VALUES (field1, field2, field3, field4, field5, field6);
COMMIT;
END;
/

-------------------------------------------------------------------------------------------------

PROMPT Create procedure dr_insert_readinessCode
CREATE OR REPLACE PROCEDURE dr_insert_readinessCode(
			field1 IN NUMBER, field2 IN  NUMBER, field3 IN  DATE,
			field4 IN  NUMBER, field5 IN CHAR, field6 IN  CHAR,
			field7 IN  NUMBER,field8 IN  CHAR, field9 IN  CHAR,
			field10 IN  NUMBER, field11 IN CHAR,field12 IN CHAR, 
			field13 IN  NUMBER, field14 IN CHAR, field15 IN CHAR,
			field16 IN  NUMBER, field17 IN CHAR, field18 IN CHAR, 
			field19 IN  NUMBER, field20 IN CHAR, field21 IN CHAR,
			field22 IN  NUMBER,field23 IN CHAR, field24 IN CHAR,
			field25 IN  NUMBER,field26 IN CHAR, field27 IN CHAR, 
			field28 IN  NUMBER,field29 IN CHAR, field30 IN CHAR, 
			field31 IN  NUMBER,field32 IN CHAR, field33 IN CHAR,
			field34 IN  NUMBER,field35 IN  CHAR, field36 IN CHAR )AS
BEGIN
INSERT INTO READINESSCODES VALUES (field1,field2,field3,field4,
	field5,field6,field7,field8,field9,field10, 
	field11,field12,field13,field14,field15,field16, 
	field17,field18,field19,field20,field21,field22, 
	field23,field24,field25,field26,field27,field28,field29,field30,field31, 
	field32,field33,field34,field35,field36);
COMMIT;
END;
/

-------------------------------------------------------------------------------------------------

PROMPT Create procedure dr_insert_safetyScore
CREATE OR REPLACE PROCEDURE dr_insert_safetyScore(
			field1	IN	NUMBER,
			field2	IN	NUMBER,
			field3	IN	NUMBER,
			field4	IN	NUMBER,
			field5	IN	CHAR,
			field6	IN	NUMBER,
			field7	IN	FLOAT,
			field8	IN	CHAR)AS
BEGIN
	INSERT INTO SAFETYSCORE (locationID, driverID, year, month, exemptDriver, score, mileage, vehicleType)
	VALUES (field1, field2, field3, field4, field5, field6, field7, field8);
	COMMIT;
END;
/

-------------------------------------------------------------------------------------------------
PROMPT Create procedure dr_insert_tamperLog
CREATE OR REPLACE PROCEDURE dr_insert_tamperLog(
			field1	IN	NUMBER,
			field2	IN	NUMBER,
			field3	IN	DATE,
			field4	IN	DATE,
			field5	IN	NUMBER,
			field6	IN	NUMBER)AS
BEGIN
	INSERT INTO TAMPERLOGS VALUES (field1, field2, field3, field4, field5, field6);
	COMMIT;
END;
/

-------------------------------------------------------------------------------------------------

PROMPT Create procedure dr_insert_trip
CREATE OR REPLACE PROCEDURE dr_insert_trip(
			field1	IN	NUMBER,
			field2	IN	NUMBER,
			field3	IN	NUMBER,
			field4	IN	DATE,
			field5	IN	DATE,
			field6	IN	NUMBER,
			field7	IN	FLOAT,
			field8	IN	NUMBER,
			field9	IN	NUMBER,
			field10	IN	NUMBER,
			field11	IN	NUMBER,
			field12	IN	FLOAT,
			field13	IN	FLOAT,
			field14	IN	NUMBER,
			field15	IN	NUMBER,
			field16	IN	CHAR,
			field17	IN	NUMBER,
			field18	IN	NUMBER,
			field19	IN	CHAR,
			field20	IN	CHAR,
			field21	IN	CHAR,
			field22	IN	NUMBER)AS
BEGIN
	INSERT INTO TRIPS VALUES (field1, field2, field3, field4, field5, field6, field7, field8, field9, field10, 
		field11, field12, field13, field14, field15, field16, field17, field18, field19, field20, field21, field22);
	COMMIT;
END;
/

-------------------------------------------------------------------------------------------------
PROMPT Create procedure dr_insert_tripAddress
CREATE OR REPLACE PROCEDURE dr_insert_tripAddress(
			field1	IN	NUMBER,
			field2	IN	NUMBER,
			field3	IN	CHAR,
			field4	IN	CHAR,
			field5	IN	CHAR,
			field6	IN	CHAR,
			field7	IN	CHAR,
			field8	IN	CHAR,
			field9	IN	CHAR,
			field10	IN	CHAR,
			field11	IN	CHAR,
			field12	IN	CHAR,
			field13	IN	CHAR,
			field14	IN	FLOAT,
			field15	IN	FLOAT,
			field16	IN	FLOAT,
			field17	IN	NUMBER,
			field18	IN	CHAR,
			field19	IN	NUMBER,
			field20	IN	NUMBER)AS
BEGIN
	INSERT INTO TRIPADDRESSES VALUES (field1, field2, field3, field4, field5, field6, field7, field8, field9, field10, 
		field11, field12, field13, field14, field15, field16, field17, field18, field19, field20);
	COMMIT;
END;
/

-------------------------------------------------------------------------------------------------

PROMPT Create procedure dr_insert_troubleCode
CREATE OR REPLACE PROCEDURE dr_insert_troubleCode(
			field1 IN NUMBER, field2 IN NUMBER, field3 IN DATE, field4 IN VARCHAR2, 
			field5 IN NUMBER, field6 IN NUMBER, field7 IN FLOAT, 
			field8 IN FLOAT, field9 IN FLOAT, field10 IN FLOAT,
			field11 IN FLOAT, field12 IN FLOAT, field13 IN FLOAT, field14 IN FLOAT, 
			field15 IN FLOAT, field16 IN FLOAT, field17 IN CHAR)AS 
BEGIN
	INSERT INTO TROUBLECODES VALUES (field1, field2, field3, field4, 
		field5, field6, field7, field8, field9, field10, field11, 
		field12, field13, field14, field15, field16, field17);
	COMMIT;
END;
/

------------------------------------------------------------------------------------------

PROMPT Create procedure dr_insert_vehicle
CREATE OR REPLACE PROCEDURE dr_insert_vehicle(
			field1 IN NUMBER, field2 IN NUMBER, field3 IN CHAR, 
			field4 IN NUMBER, field5 IN NUMBER, field6 IN NUMBER, 
			field7 IN CHAR, field8 IN CHAR, field9 IN CHAR, 
			field10 IN DATE, field11 IN FLOAT, field12 IN NUMBER, 
			field13 IN CHAR, field14 IN CHAR, field15 IN CHAR)AS
BEGIN 
	INSERT INTO VEHICLES VALUES (field1, field2, field3, field4, 
		field5, field6, field7, field8, field9, field10, field11,	
		field12, field13, field14, field15);
	COMMIT;
END;
/

------------------------------------------------------------------------------------------

PROMPT Create procedure dr_insert_wirelessDevices
CREATE OR REPLACE PROCEDURE dr_insert_wirelessDevices(
			in_serialNumHigh	IN	NUMBER,
			in_serialNumLow		IN	NUMBER,
			in_locationID      	IN	NUMBER,
			in_PANID      		IN	NUMBER,
			in_deviceType   	IN	NUMBER,
			in_baseStationPos	IN	VARCHAR2,
			in_USBSerialNum		IN	VARCHAR2,
			in_vehicleID       	IN	NUMBER,
			in_autoDownload    	IN	NUMBER,
			in_lastDownloadStatus 	IN	NUMBER,
			in_driveRightID IN	NUMBER)AS
BEGIN
	INSERT INTO WIRELESSDEVICES ( SERIALNUMHIGH, SERIALNUMLOW, LOCATIONID, PANID, DEVICETYPE,
				 BASESTATIONPOS, USBSerialNum, VEHICLEID, AUTODOWNLOAD, LASTDOWNLOADSTATUS, DRIVERIGHTID) 
		VALUES( in_serialNumHigh,
			in_serialNumLow,
			in_locationID,
			in_PANID,
			in_deviceType,
			in_baseStationPos,
			in_USBSerialNum,
			in_vehicleID,
			in_autoDownload,
			in_lastDownloadStatus,
			in_driveRightID);
	COMMIT;
END;
/

------------------------------------------------------------------------------------------

PROMPT Create procedure dr_update_wirelessDevices
CREATE OR REPLACE PROCEDURE dr_update_wirelessDevices(
			in_serialNumHigh	IN 	NUMBER,
			in_serialNumLow		IN 	NUMBER,
			in_baseStationPos  	IN 	VARCHAR2,
			in_USBSerialNum  	IN 	VARCHAR2,
			in_vehicleID       	IN 	NUMBER,
			in_autoDownload    	IN 	NUMBER,
			in_lastDownloadStatus 	IN	NUMBER,
			in_driveRightID IN	NUMBER)AS
BEGIN
	UPDATE WIRELESSDEVICES 
	SET baseStationPos = in_baseStationPos,
		USBSerialNum = in_USBSerialNum,
		vehicleID = in_vehicleID,
		autoDownload = in_autoDownload,
		lastDownloadStatus = in_lastDownloadStatus,
		driveRightID = in_driveRightID
	WHERE serialNumHigh = in_serialNumHigh AND serialNumLow = in_serialNumLow;

	COMMIT;
END;
/

-------------------------------------------------------------------------------------------------

PROMPT Create procedure dr_insert_wlAutoDownloadCfg
CREATE OR REPLACE PROCEDURE dr_insert_wlAutoDownloadCfg(
			in_PANID		IN	NUMBER,
			in_startTime		IN	DATE,
			in_duration      	IN	NUMBER,
			in_includeWeekend 	IN	NUMBER)AS
BEGIN
	INSERT INTO WirelessAutoDownloadCfg (PANID, STARTTIME, DURATION, INCLUDEWEEKEND)
		VALUES(in_PANID, in_startTime, in_duration, in_includeWeekend);
	COMMIT;
END;
/

-------------------------------------------------------------------------------------------------

PROMPT Create procedure dr_update_wlAutoDownloadCfg
CREATE OR REPLACE PROCEDURE dr_update_wlAutoDownloadCfg(
			in_PANID		IN	NUMBER,
			in_startTime		IN	DATE,
			in_duration      	IN	NUMBER,
			in_includeWeekend 	IN	NUMBER)AS
BEGIN
	UPDATE WirelessAutoDownloadCfg 
	SET startTime = in_startTime,
		duration = in_duration,
		includeWeekend = in_includeWeekend
	WHERE PANID = in_PANID;

	COMMIT;
END;
/

-------------------------------------------------------------------------------------------------


PROMPT
PROMPT Initialize tables with default values
PROMPT

INSERT INTO Fleets(locationID, fleetNumber, fleetName)
	VALUES (1, 0, 'Default Fleet');

INSERT INTO DriverGroups(locationID, groupNumber, groupName)
	VALUES (1, 0, 'Default Group');

INSERT INTO DriveRights(locationID, driveRightID, vehicleID, driveRightType, speedLimit,
		accelLimit, decelLimit, settingsCode, stopTime, logOutTime,
		VSS, pulsesPerReading, calibrationNumber, distanceUnit, dateMode,
		timeMode,  alarmMode, warnNOTLogged, tamperLight)
   	VALUES (1, 0, 0, 0, 65, 30, 35, 0, 10, 0, 0, 0, 0, 2, 4, 0, 0, 0, 0); 	

INSERT INTO CarChips(locationID, carChipID, serialNumber, carChipType, vehicleID, driverID, speedBand1, 
		speedBand2, speedBand3, hardBraking, extremeBraking, hardAccel, extremeAccel,
		parameter1, interval1, parameter2, interval2, parameter3, interval3,
		parameter4, interval4, parameter5, interval5, alarmState, LEDState, downloadConfig)
	VALUES (1, 0, '0', 0, 0, 0, 45, 60, 70, 3.4323275, 4.903325, 2.941995, 4.4129925, 1, 1, 2, 5, 4, 5, 0, 5, 0, 5, 1, 1, 1); 	

INSERT INTO Drivers(locationID, driverID, groupNumber, driverName)
	VALUES (1, 0, 0, 'Unknown Driver (None)');

INSERT INTO Vehicles(locationID, vehicleID, vehicleNumber, fleetNumber, driveRightID, driverID, currentOdometer)
	VALUES (1, 0, 0, 0, 0, 0, 0);

--This version number needs to be updated for each release.

INSERT INTO CONFIG(CONFIG_KEY, CONFIG_VALUE)
	VALUES ('DB_VERSION', '3.9.3');

COMMIT;

-------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------

PROMPT
PROMPT 
PROMPT *** ORACLE Schema Creation Complete ***
PROMPT 

-- Statistic Information
-- 
SELECT CONFIG_VALUE DATABASE_VERSION FROM CONFIG WHERE CONFIG_KEY = 'DB_VERSION';

PROMPT
PROMPT Tables:
PROMPT
SELECT TABLE_NAME FROM USER_TABLES ORDER BY TABLE_NAME;

PROMPT
PROMPT Stored Procedures:
PROMPT
SELECT OBJECT_NAME FROM USER_OBJECTS WHERE OBJECT_TYPE = 'PROCEDURE' ORDER BY OBJECT_NAME;

PROMPT
PROMPT Invalid Stored Procedures:
PROMPT
SELECT OBJECT_NAME FROM USER_OBJECTS WHERE OBJECT_TYPE = 'PROCEDURE' AND STATUS = 'INVALID' ORDER BY OBJECT_NAME; 

SPOOL OFF

EXIT





