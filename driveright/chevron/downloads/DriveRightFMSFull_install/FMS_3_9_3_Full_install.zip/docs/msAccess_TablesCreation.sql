--**************************************************************************
-- 04/25/2007 Susan Xie: changed data type of CODE column in TROUBLECODES table to CHAR from NUMBER.
-- 07/12/2007 Susan Xie: added column DownloadConfig to CarChip table.
-- 08/29/2007 Susan Xie: added column DriveRightID to WirelessDevices table.
--				This is to support the wireless download for CC FleetPro assigned to Driver.
-- 09/20/2007 Susan Xie: added CarChipParameters table.
-- 02/27/2008 Susan Xie: added IdleTime column to Trips table.
-- 06/18/2008 Susan Xie: update database version to 3.9.1
-- 08/15/2008 Susan Xie: update database version to 3.9.2
-- 04/16/2009 Susan Xie: update database version to 3.9.3
--
--
--**************************************************************************

CREATE TABLE CompanyLocations (locationID        SMALLINT  PRIMARY KEY, 
                               locationName      CHAR(40)  NOT NULL   ,
      			       locationAddress   CHAR(80)             ,  
			       parentLocationID  SMALLINT 		,
			       levelNum  	 SMALLINT 		,
				extraField1       SMALLINT 		,
				extraField2         CHAR(40) );

CREATE TABLE DriveRights (locationID        SMALLINT  NOT NULL, 
			  driveRightID      SMALLINT  NOT NULL,
 			  vehicleID         SMALLINT	      ,
		          driveRightType    SMALLINT	      , 
			  speedLimit        SMALLINT	      ,
		          accelLimit        SMALLINT	      ,
      			  decelLimit        SMALLINT	      ,
		          settingsCode      SMALLINT	      ,
                          stopTime          SMALLINT          ,
                          logOutTime        SMALLINT	      ,
                          VSS               INTEGER	      ,
                          pulsesPerReading  SMALLINT          ,
                          calibrationNumber INTEGER	      ,
                          distanceUnit      BYTE	      ,
      			  dateMode          BYTE	      ,
		          timeMode          BYTE	      ,
			  alarmMode         BYTE 	      ,
			  warnNotLogged     BYTE 	      ,
                          tamperLight       BYTE	      ,
     		          activeField	    BYTE   	      ,
                          remarks           CHAR(80)	      ,
   	                  CONSTRAINT primaryKey PRIMARY KEY (locationID, driveRightID) );

CREATE TABLE CarChips (
		locationID        SMALLINT  NOT NULL, 
		carChipID         SMALLINT  NOT NULL, 
		serialNumber      CHAR(20)  NOT NULL, 
		carChipType       SMALLINT			, 
		vehicleID         SMALLINT			, 
		driverID          SMALLINT			, 
		speedBand1        SMALLINT			, 
		speedBand2        SMALLINT			, 
		speedBand3        SMALLINT			, 
		hardBraking       REAL			    , 
		extremeBraking    REAL			    , 
		hardAccel         REAL			    , 
		extremeAccel      REAL			    , 
		parameter1        SMALLINT			, 
		interval1         SMALLINT			, 
		parameter2        SMALLINT			, 
		interval2         SMALLINT			, 
		parameter3        SMALLINT			, 
		interval3         SMALLINT			, 
		parameter4        SMALLINT			, 
		interval4         SMALLINT			, 
		parameter5        SMALLINT			, 
		interval5         SMALLINT			, 
		alarmState        BYTE				, 
		LEDState		 BYTE				, 
		downloadConfig   SMALLINT			,
		CONSTRAINT primaryKey PRIMARY KEY (locationID, carChipID) );   


CREATE TABLE CarChipParameters  (
			locationID		SMALLINT   NOT NULL, 
			carChipID		SMALLINT   NOT NULL, 
			logType			SMALLINT	NOT NULL, 
			logDateTime		DATETIME	NOT NULL,
			logValue		REAL,
			CONSTRAINT primaryKey PRIMARY KEY (locationID, carChipID, logType, logDateTime) );


CREATE TABLE DriverGroups (locationID        SMALLINT  NOT NULL, 
		      	   groupNumber       SMALLINT  NOT NULL,
			   groupName         CHAR(60)  NOT NULL,
      			   remarks           CHAR(60)	       ,
			   CONSTRAINT primaryKey PRIMARY KEY (locationID, groupNumber));

CREATE TABLE Drivers (locationID        SMALLINT  NOT NULL,
   		      driverID          SMALLINT  NOT NULL,
                      groupNumber       SMALLINT  	  ,
                      driverName        CHAR(60)  NOT NULL,
                      initials          CHAR(5)		  ,
                      address           CHAR(80)   	  ,
                      city_state        CHAR(60)  	  ,
                      zipCode           CHAR(20)   	  ,
                      phoneNumber       CHAR(20)  	  ,
                      email             CHAR(80)	  ,
                      companyName       CHAR(80)  	  ,
                      employeeID        CHAR(15)	  ,
     		      activeField	BYTE   	  	  ,
                      remarks           CHAR(80)	  ,
	              CONSTRAINT primaryKey PRIMARY KEY (locationID, driverID));

CREATE TABLE Fleets (locationID        SMALLINT  NOT NULL,
                     fleetNumber       SMALLINT  NOT NULL,
                     fleetName         CHAR(40)  NOT NULL,
         	     CONSTRAINT primaryKey PRIMARY KEY (locationID, fleetNumber));

CREATE TABLE Vehicles (locationID        SMALLINT  NOT NULL,
                       vehicleID         SMALLINT  NOT NULL,
                       vehicleNumber     CHAR(80)	   ,
	               fleetNumber       SMALLINT  NOT NULL,
                       driveRightID      SMALLINT  NOT NULL,
                       driverID          SMALLINT  NOT NULL,
                       make_model        CHAR(80)      	   ,
                       licensePlate      CHAR(20)  	   ,
                       color             CHAR(10)          ,
                       purchaseDate      DATETIME	   ,                     
                       currentOdometer   REAL      NOT NULL,
	               vehicleType       SMALLINT	   ,
                       digitalInputs     BYTE              ,
     		       activeField	 BYTE   	   ,
                       remarks           CHAR(80)	      ,
       	               CONSTRAINT primaryKey PRIMARY KEY (locationID, vehicleID));

CREATE TABLE Trips (locationID        SMALLINT  NOT NULL,
	            driveRightID      SMALLINT  NOT NULL,
	            driverID          SMALLINT  NOT NULL,
                    startDateTime     DATETIME  NOT NULL,
                    endDateTime       DATETIME  NOT NULL,
                    tripTime          SMALLINT  NOT NULL,
                    distance          REAL	NOT NULL,      
                    vehicleID         SMALLINT  NOT NULL, 
                    averageSpeed      SMALLINT  NOT NULL, 
                    topSpeed          SMALLINT  NOT NULL,
                    timeOverSpeed     INTEGER   NOT NULL,
	            startOdometer     REAL      NOT NULL,
	            endOdometer       REAL      NOT NULL,
                    accelCount        SMALLINT  NOT NULL, 
                    decelCount        SMALLINT  NOT NULL, 
                    tripType          BYTE	NOT NULL,
	            fromAddress       SMALLINT		,        
                    toAddress         SMALLINT		,
                    reason            CHAR(80)		,
                    startState        BYTE		,
                    endState          BYTE		,
                    idleTime          INTEGER  ,
	            CONSTRAINT primaryKey PRIMARY KEY (locationID, driveRightID, driverID, startDateTime));

CREATE TABLE TripAddresses (locationID        SMALLINT  NOT NULL,
	                    addressID         SMALLINT  NOT NULL,
                            name              CHAR(80)  NOT NULL,
                            companyName       CHAR(40)		,
                            contactPerson     CHAR(40)		,
                            address           CHAR(80)		,
                            city              CHAR(40)		,
                            state             CHAR(40)		,
                            zipCode           CHAR(40)		,
                            country           CHAR(40)		,
                            telephone         CHAR(20)		,
                            fax               CHAR(20)		,
                            email             CHAR(80)		,
                            latitude          REAL		,
                            longitude         REAL		,
                            elevation         REAL		,
                            addressRadius     SMALLINT		,
                            ExtraStr          CHAR(80)		,
                            ExtraInt1         SMALLINT		,
                            ExtraInt2         SMALLINT		,
	                    CONSTRAINT primaryKey PRIMARY KEY (locationID, addressID));

CREATE TABLE TamperLogs (locationID        SMALLINT  NOT NULL,
                         driveRightID      SMALLINT  NOT NULL,
	                 tamperDateTime    DATETIME  NOT NULL,
	                 downloadDateTime  DATETIME	     ,
                         driverID          SMALLINT  NOT NULL,
	                 cause             SMALLINT  NOT NULL,
	                 CONSTRAINT primaryKey PRIMARY KEY (locationID, driveRightID, tamperDateTime, cause));

CREATE TABLE AccidentLogs (locationID         SMALLINT  NOT NULL,
         		   driveRightID       SMALLINT  NOT NULL,
		 	   accidentDateTime   DATETIME  NOT NULL,
                           driverID           SMALLINT  NOT NULL,
                           realOrDecel        BYTE	NOT NULL,
                           cause	      BYTE		,
                           before_T19         SMALLINT		,
                           brakeBefore_T19    BYTE		,
                           before_T18         SMALLINT		,
                           brakeBefore_T18    BYTE		,
                           before_T17         SMALLINT		,
                           brakeBefore_T17    BYTE		,
                           before_T16         SMALLINT		,
                           brakeBefore_T16    BYTE		,
                           before_T15         SMALLINT		,
                           brakeBefore_T15    BYTE		,
                           before_T14         SMALLINT		,
                           brakeBefore_T14    BYTE		,
                           before_T13         SMALLINT		,
                           brakeBefore_T13    BYTE		,
                           before_T12         SMALLINT		,
                           brakeBefore_T12    BYTE		,
                           before_T11         SMALLINT		,
                           brakeBefore_T11    BYTE		,
                           before_T10         SMALLINT		,
                           brakeBefore_T10    BYTE		,
                           before_T09         SMALLINT		,
                           brakeBefore_T09    BYTE		,
                           before_T08         SMALLINT		,
                           brakeBefore_T08    BYTE		,
                           before_T07         SMALLINT		,
                           brakeBefore_T07    BYTE		,
                           before_T06         SMALLINT		,
                           brakeBefore_T06    BYTE		,
                           before_T05         SMALLINT		,
                           brakeBefore_T05    BYTE		,
                           before_T04         SMALLINT		,
                           brakeBefore_T04    BYTE		,
                           before_T03         SMALLINT		,
                           brakeBefore_T03    BYTE		,
                           before_T02         SMALLINT		,
                           brakeBefore_T02    BYTE		,
                           before_T01         SMALLINT		,
                           brakeBefore_T01    BYTE		,
	                   time_T0            SMALLINT		,
                           brakeAt_T0	      BYTE		,
	                   after_T01          SMALLINT		,
                           brakeAfter_T01     BYTE		,
	                   after_T02          SMALLINT		,
                           brakeAfter_T02     BYTE		,
	                   after_T03          SMALLINT		,
                           brakeAfter_T03     BYTE		,
	                   after_T04          SMALLINT		,
                           brakeAfter_T04     BYTE		,
	                   after_T05          SMALLINT		,
                           brakeAfter_T05     BYTE		,
	                   after_T06          SMALLINT		,
                           brakeAfter_T06     BYTE		,
	                   after_T07          SMALLINT		,
                           brakeAfter_T07     BYTE		,
	                   after_T08          SMALLINT		,
                           brakeAfter_T08     BYTE		,
	                   after_T09          SMALLINT		,
                           brakeAfter_T09     BYTE		,
	                   after_T10          SMALLINT		,
                           brakeAfter_T10     BYTE		,
	                   after_T11          SMALLINT		,
                           brakeAfter_T11     BYTE		,
	                   after_T12          SMALLINT		,
                           brakeAfter_T12     BYTE		,
	                   after_T13          SMALLINT		,
                           brakeAfter_T13     BYTE		,
	                   after_T14          SMALLINT		,
                           brakeAfter_T14     BYTE		,
	                   after_T15          SMALLINT		,
                           brakeAfter_T15     BYTE		,
	                   after_T16          SMALLINT		,
                           brakeAfter_T16     BYTE		,
	                   after_T17          SMALLINT		,
                           brakeAfter_T17     BYTE		,
	                   after_T18          SMALLINT		,
                           brakeAfter_T18     BYTE		,
	                   after_T19          SMALLINT		,
                           brakeAfter_T19     BYTE		,
	                   after_T20          SMALLINT		,
                           brakeAfter_T20     BYTE		,
	                   latitude           REAL		,
	                   longitude          REAL		,
	                   CONSTRAINT primaryKey PRIMARY KEY (locationID, driveRightID, accidentDateTime));

CREATE TABLE Days (locationID        SMALLINT  NOT NULL,
                   driveRightID      SMALLINT  NOT NULL,
                   dayDate           DATETIME  NOT NULL,
                   day               SMALLINT  NOT NULL,
                   driverID          SMALLINT  NOT NULL,
	           totalDistance     REAL  	       ,
	           highSpeed         SMALLINT          ,
	           timeOfHighSpeed   SMALLINT          ,
	           timeOverSpeed     SMALLINT          ,
	           totalTime         SMALLINT          ,
	           accelCount        SMALLINT          ,
	           decelCount        SMALLINT          ,
	           speedLimit        SMALLINT          ,
                   accelLimit        SMALLINT          ,
                   decelLimit        SMALLINT          ,
                   driveRightType    SMALLINT          ,
	           firstMove         SMALLINT          ,
	           lastMove          SMALLINT          ,
	           timeInMotion      SMALLINT          ,
	           highAccel         SMALLINT          ,
	           highAccelTime     SMALLINT          ,
  	           CONSTRAINT primaryKey PRIMARY KEY (locationID, driveRightID, dayDate));

CREATE TABLE DownloadDates (locationID        SMALLINT  NOT NULL,
                            driveRightID      SMALLINT  NOT NULL,
                            downloadDate      DATETIME  NOT NULL,
                            daysSince         SMALLINT  NOT NULL,
                            driverID          SMALLINT  NOT NULL,
	                    CONSTRAINT primaryKey PRIMARY KEY (locationID, driveRightID, downloadDate));

CREATE TABLE Password (locationID        SMALLINT  NOT NULL,
                       userName          CHAR(40)  NOT NULL,
                       password          CHAR(40)  NOT NULL,
                       userType          BYTE	   NOT NULL,
                       driveRtAccess     BYTE      NOT NULL,
	               drBackup          BYTE	    	   ,
	               drRestore         BYTE	    	   ,
	               drImport          BYTE	    	   ,
	               drExport          BYTE	    	   ,
	               drPreferences     BYTE	    	   ,
	               drMaintenance     BYTE	    	   ,
	               reports           BYTE	    	   ,
	               locations         BYTE	    	   ,
	               driveRights       BYTE	    	   ,
	               driverGroups      BYTE	    	   ,
	               drivers           BYTE	    	   ,
	               fleets            BYTE	    	   ,
	               vehicles          BYTE	    	   ,
	               trips             BYTE	    	   ,
	               accidentLogs      BYTE	    	   ,
	               tamperLogs        BYTE	    	   ,
	               addresses         BYTE	    	   ,
	               days              BYTE	    	   ,
	               downloadDates     BYTE	    	   ,
	               gps               BYTE	    	   ,
		       odometerLogs      BYTE	    	   ,
		       safetyScore       BYTE	    	   ,
		       corpStructure     BYTE	    	   ,
	               CONSTRAINT primaryKey PRIMARY KEY (userName));

CREATE TABLE GPS (locationID        SMALLINT  NOT NULL,
                  driveRightID      SMALLINT  NOT NULL,
                  gpsDateTime       DATETIME  NOT NULL,
                  day               SMALLINT	      ,
                  driverID          SMALLINT	      ,
	          speed		    SMALLINT	      ,
	          direction	    REAL	      ,
	          highSpeed         SMALLINT	      ,
	          latitude          REAL	      ,
	          longitude         REAL	      ,
	          gpsStatus         INTEGER	      ,
	          vehicleState      BYTE	      ,
                  CONSTRAINT primaryKey PRIMARY KEY (locationID, driveRightID, gpsDateTime));

CREATE TABLE OdometerLogs (locationID         SMALLINT  NOT NULL,
                           driveRightID       SMALLINT  NOT NULL,
  	                   adjustmentDateTime DATETIME  NOT NULL,
                           vehicleID          SMALLINT  NOT NULL,
                           odometerValue      REAL      NOT NULL,
	                   cause              CHAR(40)          ,
	                   CONSTRAINT primaryKey PRIMARY KEY (locationID, driveRightID, adjustmentDateTime));


CREATE TABLE SafetyScore  (locationID         SMALLINT  NOT NULL,
                           driverID           SMALLINT  NOT NULL,
  	                   year               SMALLINT  NOT NULL,
                           month              SMALLINT  NOT NULL,                     
                           exemptDriver	      BYTE		,
	                   score	      SMALLINT  	,
			   mileage	      REAL  		,
			   vehicleType        BYTE      NOT NULL,
			   recalcScore   BYTE		,
			   extraByte         BYTE	     	, 
			   extraInt1         INTEGER           ,
			   extraInt2         INTEGER           , 
			   extraFloat         REAL			, 
	                   CONSTRAINT primaryKey PRIMARY KEY (locationID, driverID, year, month, vehicleType));


CREATE TABLE ReadinessCodes (
      	  locationID		SMALLINT	NOT NULL, 
      	  carChipID		SMALLINT	NOT NULL, 
	  codeDateTime		DATETIME	NOT NULL, 
	  cmCode		SMALLINT	NOT NULL, 
	  cmSupported		BYTE		NOT NULL, 
	  cmStatus		BYTE		NOT NULL, 
	  hcmCode		SMALLINT	NOT NULL, 
	  hcmSupported		BYTE		NOT NULL, 
	  hcmStatus		BYTE		NOT NULL, 
	  esmCode		SMALLINT	NOT NULL, 
	  esmSupported		BYTE		NOT NULL, 
	  esmStatus		BYTE		NOT NULL, 
	  sasmCode		SMALLINT	NOT NULL, 
	  sasmSupported		BYTE		NOT NULL, 
	  sasmStatus		BYTE		NOT NULL, 
	  asrmCode		SMALLINT	NOT NULL, 
	  asrmSupported		BYTE		NOT NULL, 
	  asrmStatus		BYTE		NOT NULL, 
	  osmCode		SMALLINT	NOT NULL, 
	  osmSupported		BYTE		NOT NULL, 
	  osmStatus		BYTE		NOT NULL, 
	  oshmCode		SMALLINT	NOT NULL, 
	  oshmSupported		BYTE		NOT NULL, 
	  oshmStatus		BYTE		NOT NULL, 
	  egrsmCode		SMALLINT	NOT NULL, 
	  egrsmSupported	BYTE		NOT NULL, 
	  egrsmStatus		BYTE		NOT NULL, 
	  mfmCode		SMALLINT	NOT NULL, 
	  mfmSupported		BYTE		NOT NULL, 
	  mfmStatus		BYTE		NOT NULL, 
	  fsmCode		SMALLINT	NOT NULL, 
	  fsmSupported		BYTE		NOT NULL, 
	  fsmStatus		BYTE		NOT NULL, 
	  ccmCode		SMALLINT	NOT NULL, 
	  ccmSupported		BYTE		NOT NULL, 
	  ccmStatus		BYTE		NOT NULL, 
	  CONSTRAINT primaryKey PRIMARY KEY (locationID, carChipID, codeDateTime));


CREATE TABLE TroubleCodes (
		locationID			SMALLINT	NOT NULL, 
		carChipID			SMALLINT	NOT NULL, 
		codeDateTime			DATETIME	NOT NULL, 
		code				CHAR(8)		NOT NULL, 
		fuelPressure			REAL, 
		intakeManifoldPressure		REAL, 
		engineCoolantTemperature	REAL, 
		calculatedLoadValue		REAL, 
		engineSpeed			REAL, 
		vehicleSpeed			REAL, 
		shortTermFuelTripBankOne	REAL, 
		shortTermFuelTripBankTwo	REAL, 
		longTermFuelTripBankOne		REAL, 		
		longTermFuelTripBankTwo		REAL, 		
		fuelSystemOneStatus		INTEGER, 
		fuelSystemTwoStatus		INTEGER, 
		comments			CHAR(80), 
		CONSTRAINT primaryKey PRIMARY KEY (locationID, carChipID, codeDateTime));
   
   
CREATE TABLE WirelessDevices (serialNumHigh 	NUMERIC,
			serialNumLow 		NUMERIC,
			locationID      	SMALLINT NOT NULL,
			PANID      		SMALLINT NOT NULL,
			deviceType   		BYTE NOT NULL,
			baseStationPos  	VARCHAR(32),
			USBSerialNum  		VARCHAR(16),
			vehicleID       	SMALLINT,
			autoDownload    	BYTE,
			lastDownloadStatus    	BYTE,
			driveRightID       	SMALLINT,
			CONSTRAINT primaryKey PRIMARY KEY (serialNumHigh, serialNumLow));


CREATE TABLE WirelessAutoDownloadCfg (
			PANID      	SMALLINT CONSTRAINT pK_wirelessAutoDownloadCfg PRIMARY KEY,
			startTime   	DATETIME NOT NULL,
			duration  	BYTE NOT NULL,
			includeWeekend  BYTE NOT NULL);

CREATE TABLE CONFIG (CONFIG_KEY	VARCHAR(32) NOT NULL,
			CONFIG_VALUE VARCHAR(32) NOT NULL,
			PRIMARY KEY(CONFIG_KEY) );

--This version number needs to be updated for each release.

INSERT INTO CONFIG(CONFIG_KEY, CONFIG_VALUE)
	VALUES ('DB_VERSION', '3.9.3');






























