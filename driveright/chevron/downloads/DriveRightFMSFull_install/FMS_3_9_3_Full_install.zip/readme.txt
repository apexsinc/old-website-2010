DriveRight Fleet Management Software Release Notes Sep 16, 2009

Important Note:

Using CarChip Fleet and Fleet with alarm in FMS:
 
As part of this software, we have also included our consumer CarChip software in a separate folder called "CarChip Installer".  CarChip has 
several additional features in addition to the safety data DriveRight handles, and these features are accessed only in the CarChip software.  
Install CarChip software if you have CarChips, and plan to use the following:
 
Diagnostic Code reading and resetting
Graphs of individual trip speed data
Tables and graphs for data on the additional parameters CarChip logs (RPM, coolant temperature, etc.)


I. Introduction

Thank you for installing DriveRight FMS. All the documentation is provided in the folder 'docs' 
on the CD. Once you install the software all these documents are copied to the install directory. Before you 
run the software please go through 'Getting Started Guide.pdf'. To view files with .pdf extension, 
you need Adobe Acrobat Reader. If you already have Acrobat Reader installed, your system will recognize and 
open the document. Otherwise, you can install the Acrobat Reader included with the CD, in the folder 'pdfRead'. 
Double-Click on ar505enu.exe to run the setup for Acrobat Reader.    

Please feel free to report your findings in any manner that suits you.  We ask only that you send all the 
feedback to support@davisnet.com . For your convenience, we included a list of questions in section IV. 
Feedback. Your feedback will go a long way in helping Davis Instruments create a  high quality product that 
satisfies your needs. 

II. System Requirements:
�	Operating System: Windows 98SE/Win NT4.0/Win ME/Win 2000/Win XP
�	RAM: 32MB (64MB or more recommended)
�	Resolution: 800x600 or higher recommended

III. Installation

The installation of new FMS should not effect your older 2.0x/2.6.1 program.  The default install directory is 
set to disk Drive:/Program Files/DriveRight/. The install program will create a new �DriveRight FMS� 
shortcut on your desktop, and you will also be able to launch the new program from the Start menu by 
selecting Start->Programs->DriveRight->DriveRight FMS. Follow the instructions mentioned in 
�Getting Started Guide.pdf� to install and configure the DriveRight FMS software.

IV.Feature Set

FMS 3.1

The DriveRight Fleet Management Software (FMS) allows you to store, view, and manipulate DriveRight data on your Windows-compatible computer. 
More specifically, FMS provides tools for sorting, tracking, analyzing and printing data, and viewing and printing reports for a number of 
individual DriveRight consoles at a number of different locations. 

 
DriveRight FMS 3.1 features include:

Tracking drivers, vehicles, locations, and service
Viewing, graphing, printing and saving "accident log" information
Multiple user levels 
Tamper logs
Sorting data and creating reports according to user-defined selection criteria
Summarize data by day and by trip
Integrated Microsoft MapPoint support for mapping of GPS data
Compare vehicles, drivers, or groups of drivers
FTP Export / FTP Import data
Palm download support

FMS 3.2

DriveRight Fleet Management Software version 3.2 includes the following changes:

�Driver Safety Score Report: (Previously it's called as Driver Performance Score report)   
Changes have been made to this report in order to support exempt driver functionality.                        
Support for multiple locations.
Formula Dialog change.
User can choose to display both heavy and light vehicles or *only* light vehicles. User can choose to allow scores below zero. (If not selected then scores below zero default to zero value)
Report is going to include new column showing the DriveRight device speed limit and calculation of the score is based on that speed limit.

�Safety Score Report Summary:
Support for multiple locations.
Rolling summary report over a period of 3,6,12 months.  
Support for recalculating the score if user edited certain trips through the trips browser.

�Safety Score database table:
Added new Safety Score database table for browsing and editing the records.
Provide filter for browsing selected drivers in a particular period of time.
Support Backup, Restore, LAN Export, LAN Import, FTP Export and FTP Import for Safety Score table.

�MapPoint Integration:
Integrated MapPoint ActiveX control in the application.
Support for showing Accident Logs on the map and at the same time export to excel sheet for graphical display of the logs. Users will be able to see the trip made during a particular accident log by double clicking on the log.
Support for showing individual trips and trips made by a particular driver in a day.
Implemented Email and printing capabilities of the generated map by automating Microsoft Outlook through FMS application.
Provided data mapping wizard for specifying speed limits(Allowed up to 8 different ranges).
Users will be able to save the generated map and open it when necessary to view the saved map.

�Tamper Logs Report:
Displaying the time between unplugging the DriveRight device from the vehicle and downloading the device, time taken by the driver  to reconnect the device once finished the downloading


�Exclusive Driver:
Make changes to the Vehicles user interface while adding, editing and browsing Vehicles database table that supports exclusive driver for a particular vehicle. 
Implemented necessary changes while downloading the device based on exclusive driver logic.


�New Menu Items:
Added new menu items for Safety Score Summary report and Safety Score database table.

�Excel templates:
Fixed the problems with Accident report template for emailing.
Changed all the excel templates to excel worksheets.
Fixed up bugs while opening saved template sheets and emailing the saved workbooks.



FMS 3.3

DriveRight Fleet Management Software version 3.3 includes the following changes:

�The Inclusion of using an on-board and desktop reader and SmartCard system to transfer data from the DriveRight 600 and 500AL unit to a computer. 
This added feature has created the following changes to the FMS software.

�New menu option in the Setup Menu: SmartCard Reader. Lets you select the SmartCard reader type. The SmartCard Reader requires USB driver 
installation before the SmartCard Reader can be determined and set up.

�New menu: SmartCard Menu. The SmartCard menu contains several menu options for setting up, monitoring, and maintaining all the SmartCards and 
DriveRights using the SmartCard System. The SmartCard menu options are:

�Download  - Downloads information stored on a card to a selected base from a SmartCard Reader.
Setup Card - Allows you to select user and vehicle information for a card.
Transfer to DriveRight - Uses the card to transfer settings and information to a DriveRight or multiple DriveRight devices.
Clear Transfer Data - Clears the settings and data that sets the DriveRight
Erase - Erases all data stored on the SmartCard



FMS 3.4 

DriveRight Fleet Management Software version 3.4 includes the following changes:

�New option in Setup Menu: Corporate Structure. The Corporate Structure option allows you to create a hierarchical representation of 
fleets and how they are distributed company wide. This feature is used in conjunction with the Driver Safety Score Report in the Reports Menu.

�A new option in the Drive Safety Score Report: Specify Drivers with Mileage option, which displays all drivers with mileage for the specified time period.

�The Serial Port options for both DriveRight and CarChip changed to Communication Port in the Setup Menu, with added USB support.

�USB support for Fleet CarChips added.


FMS 3.5

DriveRight Fleet Management Software version 3.5 includes the following changes:

�The current selected location is now displayed on the title bar of FMS. This allows you to know which 
location's data is currently being viewed through any window or table in the FMS software.

�Three new options in Database Menu: Readiness Code Database, Trouble Code Database, and Batch Editing. 

�The Readiness Code Database allows you to view all the monitored readiness codes and the status of each 
code if you use the CarChip Fleet device.

�The Trouble Code Database allows you to review any trouble code records recorded in a vehicle using the 
CarChip Fleet device.

�The Batch Editing feature allows you to re-assign drivers or adjust speeds displayed in all the tables 
in the database of various trips.

�The CarChip database table has changed to display the interval the CarChip device now logs speed measurements.

�Miscellaneous Settings has been added to the Add CarChip Wizard and to the CarChip Settings dialog box. 
Miscellaneous Settings allows you to control the settings for extra features on the CarChip, such Alarm and LED. 
The CarChip Settings dialog box also allows you to chose the update interval the CarChip device now records speed. 
Previously, the Vehicle Speed and Update Interval boxes were defaults and could not be user defined. 
Now, the Interval at which vehicle speed is sampled can be selected.

�A new option was added to the Download Options dialog box that allows you to specify the number of hours of 
GPS data you want the DriveRight device to store.

�Fixed a previous issue with the DriveRight and FMS software not recording a second trip that happens 
within the same minute as a previous trip. The DriveRight device and FMS software now display all trips, even those having the same starting times.

�New database stored procedures have been added. If the software is accessing a database run on a MS SQL Server 
or Oracle server, some specialized installation may be required. See The Database Selection Guide for more 
information and complete instructions.


FMS 3.6

DriveRight Fleet Management Software version 3.6 Beta includes the following changes:

�Release date was removed from the application title bar to avoid confusion. About dialog information was revised. 

�Changes were made to support the new DriveRight 600E.  It is very similar to the 600 (with respect to the software) 
except it has a new DriveRight setting "Disable Console Login" and does not support the internal odometer.

�GPS data is not written for trips you already have in the database (eliminates erroneous "GPS data lost" message).

�Date/Time in DriveRight 600 trip download was enhanced. Now FMS handles 2-year (previous 11 months) trip data correctly.

�Download Score in Driver Safety Report was calculated as 100 instead of 0 if Max Download Days is not available (shown as "---").
 
�Days missing bug and Time Over Speed calculation was fixed. The longest Time Over Speed for one day can be saved 
without causing a day record missing depends on user's database type:
	SQLServer/Access: 	09:06:07
	Oracle:			27:46:39
	MySQL:			18:12:15 

�Oracle Database stored procedure creation have been added to FMS. 

�To simplify the manual database configuration process, database creation (tables and stored procedures) scripts 
(run from command line by DBA) for SQLServer and Oracle are implemented in this release. These scripts serve as 
a backup if any problem occurs in FMS auto database configuration.  See The Database Selection Guide for more 
information and complete instructions.

�This release was built with CarChip.dll 1.7.2.4.


FMS 3.6.1

DriveRight Fleet Management Software version 3.6.1 includes the following changes:

�User's PC name is no longer used as server alias name for SQLServer ODBC configuration.
Database name is editable to allow User to connect to any SQLServer database on the server 
besides the default database DriveRight_MSSQL.

Note: FMS document hasn't been updated to reflect these changes and will be updated in next release.


FMS 3.7

DriveRight Fleet Management Software version 3.7 includes the following changes:

�DriveRight Wireless Download 
This new feature enables the DriveRight users to download data from DriveRight remotely through FMS 
without physically removing the device from the vehicle. 

�A security measure was added to this release. The user is required to enter the 8-digit registration number 
located on registration card for validation when the first time launches FMS.

�Database migration from release to release will not solely depend on DATABASE_TYPE setting in config.txt.
Changes have been made to upgrade database when first time FMS is launched after upgrade without asking 
user to choose the database type if it has been chosen before.

�Stored procedures for Oracle database are integrated into FMS. There is no need to create 
these stored procedures manually unless FMS encounters problems when creating them.
 
�Data validation is added to ensure CarChip and DriveRight IDs are unique.

�CarChip table import and export problem is fixed.

�Download-only access right is applied to SmartCard operations in addition to DriveRight and CarChip.

�Pin Code and Driver Logout Time now can be transferred to DriveRight using SmartCard.

�Current location, displayed in the application title bar, is updated according user's modification.

�GPS logging interval range is enforced to ensure accuracy of GPS logging hours.

�Driver Logout Time for DriveRight is fixed to correctly save the user's input.

�Vehicles report is revised to contain all vehicles of the selected type (Light or Heavy) 
regardless whether the vehicle has an exclusive driver or not.


FMS 3.7.1

DriveRight Fleet Management Software version 3.7.1 includes the following changes:

�Password encryption feature is added to FMS to enforce security.

�FMS now supports multiple super users. User type can be changed by a Super User through Browse/Add Users Dialog.

�Driver Safety Score calculation is corrected when the unit mode is set to Kilometer and KM/hr.

�FMS improved in Database error handling during data downloads. User will receive a failure notification
 if database error occurs.

�CarChip settings and their default values are enforced based on CarChip models and firmware version. 

�Database CarChip record is synchronized with the CarChip device after user changes the Alarm and LED state.

�ACS SmartCard reader is the only card reader to be used with FMS for smart card data transfer. 
 ACS Proprietary Driver installation procedures and troubleshooting information are added to 
 FMS Getting Started Guide and User�s Manual.

�WirelessDevices table backup problem is fixed in SQLServer and Access Database.

�Database configuration process is improved to enforce database security and avoid object ownership problem
 in MS SQLServer database. 

�Add Unit (mph or km/hr) support for Top Speed in Excessive Speed report.

�Set date/time problem and date/time synchronization problem after download are solved for DriveRight500AL.

�Problem in adding DriveRight 500AL due to GPS checking is fixed.

�Trip records can be added or updated when the CarChip is assigned to driver.


FMS 3.7.2

DriveRight Fleet Management Software version 3.7.2 includes the following changes:

�The problem that the Pin Code transferred by SmartCard can't be recognized as valid code by DriveRight Device is fixed.

�Database failure due to duplicate record error in non-English platform is corrected.


FMS 3.8

DriveRight Fleet Management Software version 3.8 includes the following changes:

�CarChip Fleet Pro is supported in this release. 

�GPS feature is implemented for CarChip Fleet Pro. This feature allows user to collect GPS information while driving. 
 GPS logging settings can be configured through CarChip settings. FMS will store the GPS data into database during download and 
 user may create Trip map, Day Trips Map and Accident Map after download.

�Wireless Download feature is extended to CarChip Fleet Pro. User is able to download CarChip remotely 
 without physically removing the device from the vehicle.  

�The CarChip Alarm Volume feature is implemented.

�Action for next CarChip wireless download, download all data in a CarChip or download only new data since last successful download,
 is implemented. This setting can be changed through CarChip database edit dialog.

�Speed Sample logging setting in Download Options is improved to give user more flexibilities. 
 Speed sample log is now saved in CarChip Parameter Logs table. A filter dialog is implemented to allow 
 user to specify criteria when browse or delete data. Carchip Parameters Logs can be exported to 
 a text file and imported to database from the text file.

�FMS is improved to handle trouble codes recorded during trip more accurately.

�The access control to Corporate Structure now can be configured when add or edit user's privileges.

�The problem that certain value for Accel/Decel Limit for DriveRight can't be retained is fixed.

�The factors in Drivers Safety Report formula are improved to make the performance score more accurate. 
 Data Overflow problem for large fleet is solved.

�MSDE installation is no longer supported by FMS installation.

�This release was built with CarChip.dll 3.2.1.0.


FMS 3.9 (Beta Release)

DriveRight Fleet Management Software version 3.9 includes the following changes:

�Idle time feature (CarChip only) is implemented in this release. Idle time for each trip is stored in database Trips table. 
 User may run the Trip Summary Report to show the idle time for each trip and total idle time for a driver or vehicle. 
 The report can be viewed in FMS report viewer or Excel file. Email support is added to this report too. 

�FMS is improved to handle trouble codes during download to avoid trouble code missing problems. 

�Oracle database migration issues to FMS 3.8 release are solved.

�Fixed DriveRight type not displayed bug when adding a new DriveRight device.

�Increase the text limit for user name and password for FTP Import and Export.
	
�This release was built with CarChip.dll 3.2.1.0.

Note: FMS document hasn't been updated to reflect these changes and will be updated in next release.


FMS 3.9.1

DriveRight Fleet Management Software version 3.9.1 includes the following changes: 

�A new comprehensive report is added to this release to show Vehicle Activities. User can generate report for a date range, 
 selected vehicles or drivers with exception limit settings. This report can be viewed in FMS report viewer or Excel file. 
 Email support is added to this report too. This report can be accessed from Reports menu or Vehicle Activity Report toolbar button.
 
�Weekend and Night settings are moved from Usage Report to system level and can be accessed from Setup->Preferences. 
 These settings are now shared by Usage Report, Wireless Download and Vehicle activity Report.

�Improved GPS map to show coordinates within (-3, 3).

�Improved the ID validation when add/set CarChip or DriveRight device.
	
�CarChip Application 2.3.2 is included with this release.

�This release was built with CarChip.dll 3.2.1.0.


FMS 3.9.2

DriveRight Fleet Management Software version 3.9.2 includes the following changes: 

�Google Earth and Google Maps are added as additional mapping tools to Map Point. User may set mapping tool 
 from Mapping->Select Mapping Tool. Once a mapping tool is selected, Trip map, Day map and Accident Log map 
 will be generated using the selected mapping tool. Mapping with Google Earth or Google Maps requires internet 
 connection to work. User may download and install the free version of Google Earth from Google�s web site. 

�New wireless device firmware version 10E0 is available in this release. User may update the firmware of 
 Base Station and On-Board Modules through Wireless->Upgrade Firmware.

�To improve performance and reduce the file size of the Access DB, FMS will compact the database when exits
 if Access is the database type currently in use without user's confirmation. In case of error, an error message 
 will be logged in EventLog.txt.

�Import/Export, FTP Import/Export, and Backup/Restore features are now supported for database table TroubleCodes 
 and ReadinessCodes. 

�Database->Maintenance menu is now enabled/disabled properly according to user's privileges.

�In filter dialogs of Driver Safety Score report and Driver Safety Score Summary report, the current location 
 is used as default selection for Company Locations list.

�The Company Name field in Add/Edit Company Location dialog is fixed to allow company name up to 40 characters 
 and will horizontally scroll automatically.

�In Trip Summary Report, dashes are displayed for Idle Time column if the trips are from DR500.

�FMS is tested with MySQL Community server 5.1 and the compatibility issue in Driver Score Report is solved. 
 MySQL ODBC 3.51 Driver will be default driver for the Database Connection dialog for MySQL database.

�This release was built with CarChip.dll 3.2.1.0.


FMS 3.9.3

DriveRight Fleet Management Software version 3.9.3 includes the following changes: 

�FMS is now compatible with MapPoint 2009.

�A Graphical Day Report is implemented and can be accessed from Reports->Graphical Day Report menu.

�Hard Acceleration Report is added to Reports->Exception Reports collection.

�CarChip settings restore feature is added to this release and can be accessed from CarChip->CarChip Settings->Restore. 
This command will reset the CarChip settings with the database record of the selected CarChip device. 

�Set Anomalous Vehicle command is now available from FMS. The anomalous vehicle can be set using Add New CarChip wizard. 
It can also be set through CarChip->Set Anomalous Vehicle or CarChip->CarChip Settings->View/Set commands. 
Please note that this feature is not for pre-CAN version of CarChip. The supported exception vehicles and protocols 
depend on the firmware version.
 
�New wireless device firmware version 10E6 is available in this release. User may update the firmware of 
Base Station and On-Board Modules through Wireless->Upgrade Firmware. 
 
�Smart Card Reader Driver is upgraded in FMS Setup programs.

�CarChip GPS direction error is fixed.

�The download process is modifed to save the first readiness code record of each day.

�Oracle login password is encrypted to improve security.

�Connection and query timeout for Microsoft SQLServer is increased to 120 seconds.

�Calculation of Time Over Speed is improved to be more accurate. 

�Calculation of Max Download Days in Driver Safety Score report is modified for accuracy. 

�Print and Print Preview are fixed for Accident Log Report.

�CarChip Application 2.3.3 is included with this release.

�This release was built with CarChip.dll 3.2.2.0.


V. Feedback

Please send any feedback to Davis Instruments.

Davis Instruments
3465 Diablo Ave.
Hayward, CA 94545

Thanks again from the Davis DriveRight team!
